﻿using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Wordprocessing;

namespace MultiInstancePublishingHTML2Word
{
    class RandomHouseStructuring
    {
        static XDocument formating = new XDocument();

        static bool tocpresent = false;
        public static void StartConversion(string FilePath)
        {
            var ff = new FileInfo(FilePath);
            var strSourceFileName = ff.FullName.Replace(ff.Extension, "");

            strSourceFileName = strSourceFileName + "_Source" + ff.Extension;

            File.Copy(ff.FullName, strSourceFileName, true);

            ExtractStyles(strSourceFileName, System.Configuration.ConfigurationManager.AppSettings["RandomHouseWordTemplate"]);

            GlobalMethods.StyleList = GlobalMethods.ExtractStylesPart(strSourceFileName);

            GlobalMethods.StyleListRandomHouseTemplate = GlobalMethods.ExtractStylesPart(System.Configuration.ConfigurationManager.AppSettings["RandomHouseWordTemplate"]);

            //NewExtractAndStoreParaStylePropertiesInDocument(strSourceFileName);
            //ExtractAndStoreCharStylePropertiesInDocument(strSourceFileName);
            ConvertSoftEnterToHardEnters(strSourceFileName);
            ConditionalStyleMapping(strSourceFileName);

            createfootnote(strSourceFileName);

            GeneralSearchAndReplace(strSourceFileName);
            if (tocpresent == false)
            {
                GenerateAutoTOC(strSourceFileName);

                applyGTStyletoTOC(strSourceFileName);

            }
            Remove3CMStylesPart(strSourceFileName, GlobalMethods.StyleListRandomHouseTemplate);
            Addpagebreak(strSourceFileName);
            //ReplaceNumberingPart(strSourceFileName);
            // ReplaceStylingingPart(strSourceFileName);
        }
        public static void ExtractStyles(string sourceDoc, string WordTemplatePath)
        {
            //string templatePath = CopyTemplatetoProcess(WordTemplatePath);

            try
            {
                using (WordprocessingDocument wSourceDoc = WordprocessingDocument.Open(sourceDoc, true))
                {
                    //SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    //{
                    //    RemoveComments = true,
                    //    RemoveContentControls = true,
                    //    RemoveEndAndFootNotes = false,
                    //    RemoveFieldCodes = false,
                    //    RemoveLastRenderedPageBreak = true,
                    //    RemovePermissions = true,
                    //    RemoveProof = true,
                    //    RemoveRsidInfo = true,
                    //    RemoveSmartTags = true,
                    //    RemoveSoftHyphens = false,
                    //    ReplaceTabsWithSpaces = false,
                    //};

                    //MarkupSimplifier.SimplifyMarkup(wSourceDoc, settings);

                    byte[] byteArray = File.ReadAllBytes(WordTemplatePath);

                    using (MemoryStream ms = new MemoryStream())
                    {
                        ms.Write(byteArray, 0, byteArray.Length);

                        using (WordprocessingDocument doc = WordprocessingDocument.Open(ms, true))
                        {
                            XDocument xdd = doc.MainDocumentPart.StyleDefinitionsPart.GetXDocument();

                            XmlDocument xd = xdd.GetXmlDocument();

                            xd.LoadXml(xd.InnerXml);

                            XmlNodeList nodeList;

                            XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                            ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                            XmlNode root = xd.DocumentElement;
                            nodeList = root.SelectNodes("w:style", ns);

                            string strStyleID = null;
                            string strStyleName = null;

                            foreach (XmlNode book in nodeList)
                            {
                                XElement xe = book.GetXElement();

                                if (xe.HasAttributes)
                                {
                                    foreach (XAttribute xs in xe.Attributes())
                                    {
                                        if (xs.Name == W.styleId)
                                        {
                                            strStyleID = xs.Value;
                                            break;
                                        }
                                    }
                                }

                                if (xe.HasElements)
                                {
                                    foreach (XElement xee in xe.Elements())
                                    {
                                        if (xee.Name == W.name)
                                        {
                                            foreach (XAttribute xs in xee.Attributes())
                                            {
                                                if (xs.Name == W.val)
                                                {
                                                    strStyleName = xs.Value;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }

                                if (strStyleID != null)
                                {

                                    //CheckandRemoveStyleFromTemplate(doc, strStyleID);

                                    // Check if the Style exist in the Target XML with the Style ID
                                    //CopyStyleFromTemplate(strStyleID, strStyleName, xe, xd.DocumentElement.Name);

                                    if (IsStyleIdInDocument(wSourceDoc, strStyleID) == false)
                                    {
                                        AddNewStyle(wSourceDoc.MainDocumentPart.StyleDefinitionsPart, strStyleID, strStyleName, xe);
                                    }

                                    // If the Style ID does not exist in the Target XML then check with the Style Name

                                    //if (strStyleName != null)
                                    //{

                                    //}
                                }

                                strStyleID = null;
                                strStyleName = null;

                            } // End of loop
                        }
                    }// Target Loop End
                } // Source Loop End
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        } // End function

        // Create a new style with the specified styleid and stylename and add it to the specified
        // style definitions part.
        private static void AddNewStyle(StyleDefinitionsPart styleDefinitionsPart,
            string styleid, string stylename, XElement xe)
        {
            // Get access to the root element of the styles part.
            Styles styles = styleDefinitionsPart.Styles;

            XmlNode xd = xe.GetXmlNode();

            Style sty = new Style(xd.OuterXml);
            styles.Append(sty);
        }


        // Return true if the style id is in the document, false otherwise.
        private static bool IsStyleIdInDocument(WordprocessingDocument doc,
            string styleid)
        {
            // Get access to the Styles element for this document.
            Styles s = doc.MainDocumentPart.StyleDefinitionsPart.Styles;

            // Check that there are styles and how many.
            int n = s.Elements<Style>().Count();
            if (n == 0)
                return false;

            //&& (st.Type == StyleValues.Paragraph)
            // Look for a match on styleid.
            Style style = s.Elements<Style>()
                .Where(st => (st.StyleId.Value == styleid))
                .FirstOrDefault();
            if (style == null)
            {
                return false;
            }

            return true;
        }
        public static void NewExtractAndStoreParaStylePropertiesInDocument(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = true,//commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,//commented by Karan on 22-10-2018 for Edisis document (EQ)
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<ParagraphStyleId> S = D.Descendants<ParagraphStyleId>()
                                        .Where(c => c.Val != null).ToList();

                GlobalMethods.bIndentation = false;
                GlobalMethods.bLeftIndentation = false;
                GlobalMethods.bHangingIndentation = false;
                GlobalMethods.bFirstLineIndentation = false;

                GlobalMethods.bTextAlignment = false;
                GlobalMethods.bJustification = false;


                GlobalMethods.bParagraphBorders = false;
                GlobalMethods.bLeftBorder = false;
                GlobalMethods.bTopBorder = false;
                GlobalMethods.bRightBorder = false;
                GlobalMethods.bBottomBorder = false;
                GlobalMethods.bBetweenBorder = false;
                GlobalMethods.bBarBorder = false;

                GlobalMethods.bBold = false;
                GlobalMethods.bCaps = false;
                GlobalMethods.bEmphasis = false;
                GlobalMethods.bItalic = false;
                GlobalMethods.bSmallCaps = false;
                GlobalMethods.bUnderline = false;
                GlobalMethods.bStrike = false;
                GlobalMethods.bDoubleStrike = false;
                GlobalMethods.bCharColor = false; ///Added by Manish on 22-05-2018 for text color

                GlobalMethods.btabs = false;//Added by Karan on 22-10-2018 for Edisis document

                foreach (ParagraphStyleId PS in S)
                {
                    if (GlobalMethods.StyleList.Count > 0)
                    {
                        string key = PS.Val;
                        List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                        if (mystyle.Count > 0)
                        {

                            GlobalMethods.bIndentation = false;
                            GlobalMethods.bLeftIndentation = false;
                            GlobalMethods.bHangingIndentation = false;
                            GlobalMethods.bFirstLineIndentation = false;

                            GlobalMethods.bTextAlignment = false;
                            GlobalMethods.bJustification = false;


                            GlobalMethods.bParagraphBorders = false;
                            GlobalMethods.bLeftBorder = false;
                            GlobalMethods.bTopBorder = false;
                            GlobalMethods.bRightBorder = false;
                            GlobalMethods.bBottomBorder = false;
                            GlobalMethods.bBetweenBorder = false;
                            GlobalMethods.bBarBorder = false;

                            GlobalMethods.bBold = false;
                            GlobalMethods.bCaps = false;
                            GlobalMethods.bEmphasis = false;
                            GlobalMethods.bItalic = false;
                            GlobalMethods.bSmallCaps = false;
                            GlobalMethods.bUnderline = false;
                            GlobalMethods.bStrike = false;
                            GlobalMethods.bDoubleStrike = false;
                            GlobalMethods.bCharColor = false; ///Added by Manish on 22-05-2018 for text color

                            GlobalMethods.btabs = false;///Added by Karan on 22-10-2018

                            ParagraphProperties Pp;

                            if (((ParagraphProperties)PS.Parent) == null)
                            {
                                Pp = new ParagraphProperties();
                            }
                            else
                            {
                                Pp = ((ParagraphProperties)PS.Parent);
                            }

                            if (mystyle[0].BasedOn != null && mystyle[0].BasedOn.Val != null)
                            {
                                if ((mystyle[0].BasedOn.Val != "Normal") && (mystyle[0].BasedOn.Val != "NoParagraphStyle"))
                                {
                                    string mykey = mystyle[0].BasedOn.Val;
                                    List<Style> myBasestyle = (from kvp in GlobalMethods.StyleList where kvp.Key == mykey select kvp.Value).ToList();
                                    List<Style> strBasedOnStyleCollection = new List<Style>();
                                    strBasedOnStyleCollection.Clear();

                                    do
                                    {
                                        strBasedOnStyleCollection.Add(myBasestyle[0]);

                                        if (myBasestyle[0].BasedOn != null)
                                        {
                                            mykey = myBasestyle[0].BasedOn.Val;
                                            myBasestyle.Clear();

                                            myBasestyle = (from kvp in GlobalMethods.StyleList where kvp.Key == mykey select kvp.Value).ToList();
                                        }

                                    } while ((myBasestyle[0].BasedOn != null) && (myBasestyle[0].BasedOn.Val != null) && (myBasestyle[0].BasedOn.Val != "Normal") && (myBasestyle[0].BasedOn.Val != "NoParagraphStyle"));

                                    if (myBasestyle != null)
                                    {
                                        if (strBasedOnStyleCollection.Count > 0)
                                        {
                                            strBasedOnStyleCollection.Add(myBasestyle[0]);
                                        }
                                    }

                                    //if (strBasedOnStyleCollection.Count > 0)
                                    //{
                                    //    for (int nCounter = 0; nCounter < strBasedOnStyleCollection.Count; nCounter++)
                                    //    {
                                    //        updateParaPropertiesWithBasedOnStyle(PS, Pp, strBasedOnStyleCollection[nCounter].StyleId.Value);
                                    //    }
                                    //}
                                }
                            }


                            if (mystyle[0].StyleParagraphProperties != null)
                            {
                                if (mystyle[0].StyleParagraphProperties.Indentation != null)
                                {
                                    if (((ParagraphProperties)PS.Parent).Indentation == null)
                                    {
                                        GlobalMethods.bIndentation = true;
                                        GlobalMethods.bLeftIndentation = true;
                                        GlobalMethods.bHangingIndentation = true;
                                        GlobalMethods.bFirstLineIndentation = true;
                                        Pp.Indentation = new Indentation();
                                    }

                                    if (mystyle[0].StyleParagraphProperties.Indentation.Left != null)
                                    {
                                        if ((Pp.Indentation.Left == null)) //  || Pp.Indentation.Left == ""
                                        {
                                            Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Left.Value;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bLeftIndentation == true)
                                            {
                                                Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Left.Value;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.Indentation.Hanging != null)
                                    {
                                        if ((Pp.Indentation.Hanging == null && Pp.Indentation.FirstLine == null)) //  || Pp.Indentation.Hanging == ""
                                        {
                                            Pp.Indentation.Hanging = mystyle[0].StyleParagraphProperties.Indentation.Hanging.Value;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bHangingIndentation == true)
                                            {
                                                Pp.Indentation.Hanging = mystyle[0].StyleParagraphProperties.Indentation.Hanging.Value;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.Indentation.FirstLine != null)
                                    {
                                        if ((Pp.Indentation.FirstLine == null && Pp.Indentation.Hanging == null)) // || Pp.Indentation.FirstLine == ""
                                        {
                                            Pp.Indentation.FirstLine = mystyle[0].StyleParagraphProperties.Indentation.FirstLine.Value;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bFirstLineIndentation == true)
                                            {
                                                Pp.Indentation.FirstLine = mystyle[0].StyleParagraphProperties.Indentation.FirstLine.Value;
                                            }
                                        }
                                    }
                                }

                                if (mystyle[0].StyleParagraphProperties.Tabs != null)
                                {
                                    if (Pp.Tabs == null)
                                    {
                                        Pp.Append(mystyle[0].StyleParagraphProperties.Tabs.CloneNode(true));
                                    }
                                    else
                                    {
                                        if (GlobalMethods.btabs == true)
                                        {
                                            Pp.Append(mystyle[0].StyleParagraphProperties.Tabs.CloneNode(true));
                                        }
                                    }
                                }
                                if (mystyle[0].StyleParagraphProperties.TextAlignment != null)
                                {
                                    if ((Pp.TextAlignment == null))
                                    {
                                        Pp.TextAlignment = new TextAlignment();
                                        Pp.TextAlignment.Val = mystyle[0].StyleParagraphProperties.TextAlignment.Val;
                                    }
                                    else
                                    {
                                        if (GlobalMethods.bTextAlignment == true)
                                        {
                                            //Pp.TextAlignment = new TextAlignment();
                                            Pp.TextAlignment.Val = mystyle[0].StyleParagraphProperties.TextAlignment.Val;
                                        }
                                    }
                                }
                                if (mystyle[0].StyleParagraphProperties.Justification != null)
                                {
                                    if ((((ParagraphProperties)PS.Parent).Justification == null))
                                    {
                                        Pp.Justification = new Justification();
                                        Pp.Justification.Val = mystyle[0].StyleParagraphProperties.Justification.Val;
                                    }
                                    else
                                    {
                                        if (GlobalMethods.bJustification == true)
                                        {
                                            Pp.Justification.Val = mystyle[0].StyleParagraphProperties.Justification.Val;
                                        }
                                    }
                                }
                                else
                                {
                                    if ((((ParagraphProperties)PS.Parent).Justification == null))
                                    {
                                        Pp.Justification = new Justification();
                                        Pp.Justification.Val = DocumentFormat.OpenXml.Wordprocessing.JustificationValues.Left;
                                    }
                                    else
                                    {
                                        if (GlobalMethods.bJustification == true && mystyle[0].StyleParagraphProperties.Justification != null)
                                        {
                                            Pp.Justification.Val = DocumentFormat.OpenXml.Wordprocessing.JustificationValues.Left;
                                        }
                                    }
                                }

                                if (mystyle[0].StyleParagraphProperties.ParagraphBorders != null)
                                {
                                    if (Pp.ParagraphBorders == null)
                                    {
                                        GlobalMethods.bParagraphBorders = true;
                                        GlobalMethods.bLeftBorder = true;
                                        GlobalMethods.bTopBorder = true;
                                        GlobalMethods.bRightBorder = true;
                                        GlobalMethods.bBottomBorder = true;
                                        GlobalMethods.bBetweenBorder = true;
                                        GlobalMethods.bBarBorder = true;
                                        Pp.ParagraphBorders = new ParagraphBorders();
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.LeftBorder == null)
                                        {
                                            Pp.ParagraphBorders.LeftBorder = new LeftBorder();
                                        }

                                        if (Pp.ParagraphBorders.LeftBorder.Val == null || Pp.ParagraphBorders.LeftBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.LeftBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bLeftBorder == true)
                                            {
                                                Pp.ParagraphBorders.LeftBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.TopBorder == null)
                                        {
                                            Pp.ParagraphBorders.TopBorder = new TopBorder();
                                        }


                                        if (Pp.ParagraphBorders.TopBorder.Val == null || Pp.ParagraphBorders.TopBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.TopBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bTopBorder == true)
                                            {
                                                Pp.ParagraphBorders.TopBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.RightBorder == null)
                                        {
                                            Pp.ParagraphBorders.RightBorder = new RightBorder();
                                        }

                                        if (Pp.ParagraphBorders.RightBorder.Val == null || Pp.ParagraphBorders.RightBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.RightBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bRightBorder == true)
                                            {
                                                Pp.ParagraphBorders.RightBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.BottomBorder == null)
                                        {
                                            Pp.ParagraphBorders.BottomBorder = new BottomBorder();
                                        }

                                        if (Pp.ParagraphBorders.BottomBorder.Val == null || Pp.ParagraphBorders.BottomBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.BottomBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bBottomBorder == true)
                                            {
                                                Pp.ParagraphBorders.BottomBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.BetweenBorder == null)
                                        {
                                            Pp.ParagraphBorders.BetweenBorder = new BetweenBorder();
                                        }

                                        if (Pp.ParagraphBorders.BetweenBorder.Val == null || Pp.ParagraphBorders.BetweenBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.BetweenBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bBetweenBorder == true)
                                            {
                                                Pp.ParagraphBorders.BetweenBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.BarBorder == null)
                                        {
                                            Pp.ParagraphBorders.BarBorder = new BarBorder();
                                        }

                                        if (Pp.ParagraphBorders.BarBorder.Val == null || Pp.ParagraphBorders.BarBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.BarBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bBarBorder == true)
                                            {
                                                Pp.ParagraphBorders.BarBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder.Val;
                                            }
                                        }
                                    }
                                }
                            }
                            if (mystyle[0].StyleRunProperties != null)
                            {
                                if (PS.Parent.Parent != null)
                                {
                                    foreach (Run R in PS.Parent.Parent.Descendants<Run>().ToList())
                                    {
                                        ///GlobalMethods.bUnderline = false; added by Karan 8/2/2018 for QEHq18-00292_Exhibit2.1.docx.
                                        GlobalMethods.bUnderline = false;
                                        if (R.RunProperties == null)
                                        {
                                            // Create a new Run Properties
                                            R.RunProperties = new RunProperties();

                                            GlobalMethods.bBold = true;
                                            GlobalMethods.bCaps = true;
                                            GlobalMethods.bEmphasis = true;
                                            GlobalMethods.bItalic = true;
                                            GlobalMethods.bSmallCaps = true;
                                            GlobalMethods.bUnderline = true;
                                            GlobalMethods.bStrike = true;
                                            GlobalMethods.bDoubleStrike = true;
                                            GlobalMethods.bCharColor = true; ///Added by Manish on 22-05-2018 for text color
                                        }

                                        if (R.RunProperties.Bold == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Bold != null)
                                            {
                                                R.RunProperties.Bold = new Bold();
                                                R.RunProperties.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bBold == true)
                                            {

                                                if (mystyle[0].StyleRunProperties.Bold != null)
                                                {
                                                    if (R.RunProperties.Bold == null)// added if condition by Karan on 27-07-2018 
                                                    {
                                                        R.RunProperties.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                                    }
                                                }
                                            }
                                        }

                                        if (R.RunProperties.Caps == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Caps != null)
                                            {
                                                R.RunProperties.Caps = new Caps();
                                                R.RunProperties.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bCaps == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Caps != null)
                                                {
                                                    R.RunProperties.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                                }
                                            }
                                        }

                                        if (R.RunProperties.Emphasis == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Emphasis != null)
                                            {
                                                R.RunProperties.Emphasis = new Emphasis();
                                                R.RunProperties.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bEmphasis == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Emphasis != null)
                                                    R.RunProperties.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                            }
                                        }

                                        if (R.RunProperties.Italic == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Italic != null)
                                            {
                                                R.RunProperties.Italic = new Italic();
                                                R.RunProperties.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bItalic == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Italic != null)
                                                    R.RunProperties.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                            }
                                        }

                                        if (R.RunProperties.SmallCaps == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                            {
                                                R.RunProperties.SmallCaps = new SmallCaps();
                                                R.RunProperties.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bSmallCaps == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                                    R.RunProperties.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                            }
                                        }

                                        if (R.RunProperties.Underline == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Underline != null)
                                            {
                                                R.RunProperties.Underline = new Underline();
                                                R.RunProperties.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bUnderline == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Underline != null)
                                                    R.RunProperties.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                            }
                                        }

                                        if (R.RunProperties.Strike == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Strike != null)
                                            {
                                                R.RunProperties.Strike = new Strike();
                                                R.RunProperties.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bStrike == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Strike != null)
                                                    R.RunProperties.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                            }
                                        }

                                        if (R.RunProperties.DoubleStrike == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                            {
                                                R.RunProperties.DoubleStrike = new DoubleStrike();
                                                R.RunProperties.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bDoubleStrike == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                                    R.RunProperties.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                            }
                                        }

                                        ///Added by Manish on 22-05-2018 for text color start
                                        if (R.RunProperties.Color == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Color != null)
                                            {
                                                R.RunProperties.Color = new Color();
                                                R.RunProperties.Color.Val = mystyle[0].StyleRunProperties.Color.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bCharColor == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Color != null)
                                                    R.RunProperties.Color.Val = mystyle[0].StyleRunProperties.Color.Val;
                                            }
                                        }
                                        ///Added by Manish on 22-05-2018 for text color end
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        public static void ExtractAndStoreCharStylePropertiesInDocument(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = true,//commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = true,//commented by Karan on 22-10-2018 for Edisis document (EQ)
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<RunStyle> S = D.Descendants<RunStyle>()
                                        .Where(c => c.Val != null).ToList();

                foreach (RunStyle PS in S)
                {
                    if (GlobalMethods.StyleList.Count > 0)
                    {
                        string key = PS.Val;
                        List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                        if (mystyle.Count > 0)
                        {
                            GlobalMethods.bBold = false;
                            GlobalMethods.bCaps = false;
                            GlobalMethods.bEmphasis = false;
                            GlobalMethods.bItalic = false;
                            GlobalMethods.bSmallCaps = false;
                            GlobalMethods.bUnderline = false;
                            GlobalMethods.bStrike = false;
                            GlobalMethods.bDoubleStrike = false;
                            GlobalMethods.bVertAlignment = false;
                            GlobalMethods.bCharBorder = false;
                            GlobalMethods.bCharColor = false;

                            //27-07-2018 Addded By Karan Start
                            GlobalMethods.bshading = false;
                            GlobalMethods.bfontsize = false;
                            ///boolen declare for rstyle 
                            bool brstyle = false;
                            //27-07-2018 Addded By Karan End

                            if (mystyle[0] != null)
                            {
                                if (mystyle[0].Type == "character")
                                {
                                    if (PS.Parent != null && PS.Parent.Parent.LocalName == "r")
                                    {
                                        if (PS.Parent.LocalName == "rPr")
                                        {
                                            RunProperties rP;

                                            if (((RunProperties)PS.Parent) == null)
                                            {
                                                GlobalMethods.bBold = true;
                                                GlobalMethods.bCaps = true;
                                                GlobalMethods.bEmphasis = true;
                                                GlobalMethods.bItalic = true;
                                                GlobalMethods.bSmallCaps = true;
                                                GlobalMethods.bUnderline = true;
                                                GlobalMethods.bStrike = true;
                                                GlobalMethods.bDoubleStrike = true;
                                                GlobalMethods.bVertAlignment = true;
                                                GlobalMethods.bCharBorder = true;
                                                GlobalMethods.bCharColor = true;

                                                //27-07-2018 Addded By Karan Start
                                                GlobalMethods.bshading = false;
                                                GlobalMethods.bfontsize = false;
                                                //27-07-2018 Addded By Karan End

                                                rP = new RunProperties();
                                            }
                                            else
                                            {
                                                rP = ((RunProperties)PS.Parent);



                                                GlobalMethods.bBold = false;
                                                GlobalMethods.bCaps = false;
                                                GlobalMethods.bEmphasis = false;
                                                GlobalMethods.bItalic = false;
                                                GlobalMethods.bSmallCaps = false;
                                                GlobalMethods.bUnderline = false;
                                                GlobalMethods.bStrike = false;
                                                GlobalMethods.bDoubleStrike = false;
                                                GlobalMethods.bVertAlignment = false;
                                                GlobalMethods.bCharBorder = false;
                                                GlobalMethods.bCharColor = false;

                                                //27-07-2018 Addded By Karan Start
                                                GlobalMethods.bshading = false;
                                                GlobalMethods.bfontsize = false;
                                                //27-07-2018 Addded By Karan End
                                            }
                                            if (rP.Underline != null)
                                            {
                                                if (rP.Underline.Val != null)
                                                {
                                                    GlobalMethods.bUnderline = true;
                                                }
                                            }
                                            if (mystyle[0].BasedOn != null && mystyle[0].BasedOn.Val != null)
                                            {
                                                if ((mystyle[0].BasedOn.Val != "DefaultParagraphFont"))
                                                {
                                                    //GlobalMethods.swriter.WriteLine(mystyle[0].BasedOn.Val);
                                                    updateCharPropertiesWithBasedOnStyle(PS, rP, mystyle[0].BasedOn.Val);
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties != null)
                                            {
                                                ///27-07-2018 Start Added By Karan for cite_fig etc.
                                                if (mystyle[0].StyleRunProperties.Shading != null)
                                                {
                                                    if (rP.Shading == null)
                                                    {
                                                        rP.Shading = new Shading();
                                                        rP.Shading.Fill = mystyle[0].StyleRunProperties.Shading.Fill;
                                                        brstyle = true;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bshading == true)
                                                        {
                                                            if (rP.Shading == null)
                                                            {
                                                                rP.Shading.Fill = mystyle[0].StyleRunProperties.Shading.Fill;
                                                                brstyle = true;
                                                            }
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.FontSize != null)
                                                {
                                                    if (rP.FontSize == null)
                                                    {
                                                        rP.FontSize = new FontSize();
                                                        rP.FontSize.Val = mystyle[0].StyleRunProperties.FontSize.Val;
                                                        brstyle = true;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bfontsize == true)
                                                        {
                                                            if (rP.FontSize == null)
                                                            {
                                                                rP.FontSize.Val = mystyle[0].StyleRunProperties.FontSize.Val;
                                                                brstyle = true;
                                                            }
                                                        }
                                                    }
                                                }
                                                ///27-07-2018 End 

                                                if (mystyle[0].StyleRunProperties.VerticalTextAlignment != null)
                                                {
                                                    if (rP.VerticalTextAlignment == null)
                                                    {
                                                        rP.VerticalTextAlignment = new VerticalTextAlignment();
                                                        rP.VerticalTextAlignment.Val = mystyle[0].StyleRunProperties.VerticalTextAlignment.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bVertAlignment == true)
                                                        {
                                                            rP.VerticalTextAlignment.Val = mystyle[0].StyleRunProperties.VerticalTextAlignment.Val;
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.Italic != null)
                                                {
                                                    if (rP.Italic == null)
                                                    {
                                                        rP.Italic = new Italic();
                                                        rP.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bItalic == true)
                                                        {
                                                            rP.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.Bold != null)
                                                {
                                                    if (rP.Bold == null)
                                                    {
                                                        rP.Bold = new Bold();
                                                        rP.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bBold == true)
                                                        {
                                                            rP.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.Underline != null)
                                                {
                                                    if (rP.Underline == null)
                                                    {
                                                        rP.Underline = new Underline();
                                                        rP.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                                    }
                                                    ///comment by Manish on 10-01-2018
                                                    //else
                                                    //{
                                                    //    if (GlobalMethods.bUnderline == true)
                                                    //    {
                                                    //        rP.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                                    //    }

                                                    //}
                                                }

                                                if (mystyle[0].StyleRunProperties.Border != null)
                                                {
                                                    if (rP.Border == null)
                                                    {
                                                        rP.Border = new Border();
                                                        rP.Border.Val = mystyle[0].StyleRunProperties.Border.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bCharBorder == true)
                                                        {
                                                            rP.Border.Val = mystyle[0].StyleRunProperties.Border.Val;
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.Caps != null)
                                                {
                                                    if (rP.Caps == null)
                                                    {
                                                        rP.Caps = new Caps();
                                                        rP.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bCaps == true)
                                                        {
                                                            rP.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.Color != null)
                                                {
                                                    if (rP.Color == null)
                                                    {
                                                        rP.Color = new Color();
                                                        rP.Color.Val = mystyle[0].StyleRunProperties.Color.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bCharColor == true)
                                                        {
                                                            rP.Color.Val = mystyle[0].StyleRunProperties.Color.Val;
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                                {
                                                    if (rP.DoubleStrike == null)
                                                    {
                                                        rP.DoubleStrike = new DoubleStrike();
                                                        rP.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bDoubleStrike == true)
                                                        {
                                                            rP.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                                        }
                                                    }

                                                }

                                                if (mystyle[0].StyleRunProperties.Emphasis != null)
                                                {
                                                    if (rP.Emphasis == null)
                                                    {
                                                        rP.Emphasis = new Emphasis();
                                                        rP.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bEmphasis == true)
                                                        {
                                                            rP.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                                {
                                                    if (rP.SmallCaps == null)
                                                    {
                                                        rP.SmallCaps = new SmallCaps();
                                                        rP.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bSmallCaps == true)
                                                        {
                                                            rP.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                                        }
                                                    }
                                                }

                                                if (mystyle[0].StyleRunProperties.Strike != null)
                                                {
                                                    if (rP.Strike == null)
                                                    {
                                                        rP.Strike = new Strike();
                                                        rP.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                                    }
                                                    else
                                                    {
                                                        if (GlobalMethods.bStrike == true)
                                                        {
                                                            rP.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (brstyle == false)
                                    {
                                        //PS.Remove();
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        private static bool ConditionalStyleMapping(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveHyperlinks = true,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,

                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool bBreakRun = false;

                bool secLevel = false;
                string secLevelNum = null;
                int nsecLevelNum = 0;

                bool bPartInfoFound = false;
                DocumentFormat.OpenXml.Wordprocessing.Paragraph PrevPara = null;
                DocumentFormat.OpenXml.Wordprocessing.Run PrevRun = null;
                DocumentFormat.OpenXml.OpenXmlElement ox = null;
                bool bReferenceSection = false;
                bool btocStart = false;

                bool bctapply = false;

                int cntintro = 0;
                int cntpara = 0;

                List<string> tocPara = new List<string>();
                var bhinstyle = false;
                var bhinsprestyle = false;
                var bhintipstyle = false;

                var bquotepara = false;

                var bquoteparaBrif = false;

                var body = D.Descendants<Body>().FirstOrDefault();

                var CTfound = false;

                //new code to support Page margins in SectionProperties
                SectionProperties sectProp = new SectionProperties();

                if (D.Descendants<SectionProperties>().Count() > 0)
                {
                    sectProp = D.Descendants<SectionProperties>().FirstOrDefault();

                    if (sectProp.Descendants<PageMargin>().Count() > 0)
                    {
                        sectProp.Descendants<PageMargin>().FirstOrDefault().Remove();
                    }
                }
                PageMargin pageMargin = new PageMargin() { Top = 1134, Right = 1361, Bottom = 1021, Left = 1418, Header = 709, Footer = 709, Gutter = 0 };

                sectProp.Append(pageMargin);
                //end new code


                foreach (DocumentFormat.OpenXml.Wordprocessing.Paragraph P in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                {
                    if (P.InnerText.Trim() != "")
                    {
                        cntpara++;
                    }

                    //if(P.InnerText.Contains("Noch heute ist es üblich")||P.InnerText.Contains("Frauen fühlen sich häufig auf Grund ihrer Sozialisierung"))
                    //{
                    //    var h = P.InnerText;
                    //}
                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (/*cntpara == 1*/CTfound == false && P.InnerText.Trim() != "" && P.InnerText.TrimStart().StartsWith("Für"))
                                {
                                    CTfound = true;
                                    //P.ParagraphProperties.ParagraphStyleId.Val = "Widmung-rechtsseitig";
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "Widmung-rechtsseitig" });
                                    updateRunTOC(P);
                                }
                                if (P.InnerText == "Inhaltsverzeichnis")
                                {
                                    tocpresent = true;
                                    btocStart = true;
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "U1-neuseitig" });
                                    updateRunTOC(P);
                                    //P.ParagraphProperties.ParagraphStyleId.Val = "U1-neuseitig";
                                    goto NextPara;
                                }
                                if (P.InnerText == "Einleitung")
                                {
                                    cntintro++;

                                    if (cntintro == 1 && btocStart)
                                    {
                                        var newP = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Leerzeile" }));
                                        P.InsertAfterSelf(newP);
                                        tocPara.Add(P.InnerText);
                                        updateRunTOC(P);
                                    }

                                    if (cntintro == 2)
                                    {
                                        btocStart = false;
                                        P.ParagraphProperties.ParagraphStyleId.Val = "U1-rechtsseitig";
                                        updateRunTOC(P);
                                    }
                                }


                                if (btocStart == true)
                                {
                                    //if (P.InnerText.Trim() == "" && P.PreviousSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val == "Leerzeile")
                                    //{
                                    //    P.Remove();
                                    //    goto NextPara;
                                    //}
                                    //else if (P.InnerText.Trim() == "" && (P.PreviousSibling<Paragraph>().InnerText != "Inhaltsverzeichnis" || P.PreviousSibling<Paragraph>().InnerText != "Schlusswort"))
                                    //{
                                    //    P.ParagraphProperties.ParagraphStyleId.Val = "Leerzeile";
                                    //    goto NextPara;
                                    //}
                                    //else
                                    //{
                                    //    P.ParagraphProperties.ParagraphStyleId.Val = "GT";
                                    //    tocPara.Add(P.InnerText);
                                    //    goto NextPara;
                                    //}

                                    if (Regex.Match(P.InnerText, "[((]+Ü+[0-9]+[))]+|[((]+[0-9]+[))]+").Success)
                                    {
                                        var para = P.InnerText.Substring(0, P.InnerText.IndexOf(")")).Replace("((Ü", "");
                                        if (Regex.Match(P.PreviousSibling<Paragraph>().InnerText, "[((]+Ü+[0-9]+[))]+|[((]+[0-9]+[))]+").Success)
                                        {
                                            var paraPrev = P.PreviousSibling<Paragraph>().InnerText.Substring(0, P.InnerText.IndexOf(")")).Replace("((Ü", "");

                                            if (Convert.ToInt32(para) < Convert.ToInt32(paraPrev))
                                            {
                                                var newP = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Leerzeile" }));
                                                if (P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val != "Leerzeile")
                                                    P.InsertBeforeSelf(newP);
                                            }
                                        }
                                        P.ParagraphProperties.ParagraphStyleId.Val = "GT";


                                    }
                                    else if (!P.InnerText.Trim().Contains(" "))
                                    {
                                        var newP = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Leerzeile" }));
                                        if (P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val != "Leerzeile")
                                            P.InsertAfterSelf(newP);
                                        P.ParagraphProperties.ParagraphStyleId.Val = "GT";

                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "GT";

                                    }
                                    updateRunTOC(P);
                                }

                                else if (btocStart == false)
                                {
                                    if ((P.ParagraphProperties.ParagraphStyleId.Val == "SummaryPara" || P.ParagraphProperties.ParagraphStyleId.Val == "RomanList" || P.ParagraphProperties.ParagraphStyleId.Val == "Quote") && bquotepara == false && bhinsprestyle == false)
                                    {
                                        if (P.PreviousSibling() != null && P.PreviousSibling<Paragraph>() != null && P.PreviousSibling<Paragraph>().InnerText.Trim().EndsWith("Brief:"))
                                        {
                                            var newPstart = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "BriefAnfang" }));
                                            var run = new Run(new Text() { Text = "Brief Anfang" });
                                            newPstart.Append(run);
                                            P.InsertBeforeSelf(newPstart);

                                            bquoteparaBrif = true;
                                        }
                                        else
                                        {
                                            var newPstart = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "ZitatAnfang" }));
                                            var run = new Run(new Text() { Text = "Zitat Anfang" });
                                            newPstart.Append(run);
                                            P.InsertBeforeSelf(newPstart);
                                        }
                                        // P.ParagraphProperties.ParagraphStyleId.Val = "GT";
                                        if (P.InnerText.StartsWith("("))
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "Quelle" });
                                        }
                                        else
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "GT" });
                                        }

                                        bquotepara = true;
                                        updateRunForQuote(P);
                                        goto NextPara;
                                    }
                                    else if ((P.ParagraphProperties.ParagraphStyleId.Val == "SummaryPara" || P.ParagraphProperties.ParagraphStyleId.Val == "RomanList" || P.ParagraphProperties.ParagraphStyleId.Val == "Quote") && bquotepara == true)
                                    {
                                        //P.ParagraphProperties.ParagraphStyleId.Val = "GT";
                                        if (P.InnerText.StartsWith("("))
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "Quelle" });
                                        }
                                        else if (P.InnerText.Trim() == "")
                                        {
                                            P.Remove();
                                            bquotepara = true;
                                            goto NextPara;
                                        }
                                        else
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "GT" });
                                        }
                                        bquotepara = true;
                                        updateRunForQuote(P);
                                        goto NextPara;
                                    }
                                    else if ((P.ParagraphProperties.ParagraphStyleId.Val != "SummaryPara" || P.ParagraphProperties.ParagraphStyleId.Val != "RomanList" || P.ParagraphProperties.ParagraphStyleId.Val != "Quote") && bquotepara == true && bhinsprestyle == false)
                                    {


                                        if (bquoteparaBrif == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "BriefEnde" }));

                                            var run = new Run(new Text() { Text = "Brief Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bquoteparaBrif = false;
                                        }
                                        else
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "ZitatEnde" }));

                                            var run = new Run(new Text() { Text = "Zitat Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                        }

                                        bquotepara = false;


                                    }
                                    if (P.InnerText.Replace(" ", "").StartsWith("((Ü1") || P.ParagraphProperties.ParagraphStyleId.Val == "H1")
                                    {
                                        // P.ParagraphProperties.ParagraphStyleId.Val = "U1-neuseitig";
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "U1-neuseitig" });

                                        if (bhinstyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder02Ende" }));
                                            var run = new Run(new Text() { Text = "Sonder02 Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhinstyle = false;
                                        }
                                        else if (bhinsprestyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder01Ende" }));
                                            var run = new Run(new Text() { Text = "Sonder01 Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhinsprestyle = false;
                                        }
                                        else if (bhintipstyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "UebungEnde" }));
                                            var run = new Run(new Text() { Text = "Uebung Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhintipstyle = false;
                                        }
                                    }
                                    else if (P.InnerText.Replace(" ", "").StartsWith("((Ü2") || P.ParagraphProperties.ParagraphStyleId.Val == "H2")
                                    {
                                        // P.ParagraphProperties.ParagraphStyleId.Val = "U2";
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "U2" });

                                        if (bhinstyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder02Ende" }));
                                            var run = new Run(new Text() { Text = "Sonder02 Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhinstyle = false;
                                        }
                                        else if (bhinsprestyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder01Ende" }));
                                            var run = new Run(new Text() { Text = "Sonder01 Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhinsprestyle = false;
                                        }
                                        else if (bhintipstyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "UebungEnde" }));
                                            var run = new Run(new Text() { Text = "Uebung Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhintipstyle = false;
                                        }
                                    }
                                    else if (P.InnerText.Replace(" ", "").StartsWith("((Ü3") || P.ParagraphProperties.ParagraphStyleId.Val == "H3")
                                    {
                                        // P.ParagraphProperties.ParagraphStyleId.Val = "U3";

                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "U3" });

                                        if (bhinstyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder02Ende" }));
                                            var run = new Run(new Text() { Text = "Sonder02 Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhinstyle = false;
                                        }
                                        else if (bhinsprestyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder01Ende" }));
                                            var run = new Run(new Text() { Text = "Sonder01 Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhinsprestyle = false;
                                        }
                                        else if (bhintipstyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "UebungEnde" }));
                                            var run = new Run(new Text() { Text = "Uebung Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhintipstyle = false;
                                        }
                                    }
                                    else if (/*P.InnerText.Replace(" ", "").StartsWith("((Ü4)")*/ P.InnerText.Replace(" ", "").StartsWith("((Ü4") || P.InnerText.Replace(" ", "").StartsWith("((4))") || P.InnerText.Replace(" ", "").StartsWith("((U4))") || (P.ParagraphProperties.ParagraphStyleId.Val == "H4" && (!P.InnerText.Replace(" ", "").StartsWith("((In") && !P.InnerText.Replace(" ", "").StartsWith("((Spre") && !P.InnerText.Replace(" ", "").StartsWith("((Tip") && !P.InnerText.Replace(" ", "").StartsWith("((Abbildung"))))
                                    {
                                        //P.ParagraphProperties.ParagraphStyleId.Val = "U4";
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "U4" });

                                        if (bhinstyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder02Ende" }));
                                            var run = new Run(new Text() { Text = "Sonder02 Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhinstyle = false;
                                        }
                                        else if (bhinsprestyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder01Ende" }));
                                            var run = new Run(new Text() { Text = "Sonder01 Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhinsprestyle = false;
                                        }
                                        else if (bhintipstyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "UebungEnde" }));
                                            var run = new Run(new Text() { Text = "Uebung Ende" });
                                            newPend.Append(run);
                                            P.InsertBeforeSelf(newPend);
                                            bhintipstyle = false;
                                        }
                                        updateRunForQuote(P);
                                        goto NextPara;
                                    }

                                    else if (P.InnerText.Replace(" ", "").StartsWith("((In"))
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "Hinweis";
                                        bhinstyle = true;

                                        var newPstart = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder02Anfang" }));
                                        var run = new Run(new Text() { Text = "Sonder02 Anfang" });
                                        newPstart.Append(run);
                                        P.InsertBeforeSelf(newPstart);
                                        if (bhinsprestyle == true)
                                        {
                                            var newPend = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder01Ende" }));
                                            newPstart.InsertBeforeSelf(newPend);
                                            bhinsprestyle = false;
                                        }
                                        updateRun(P);
                                        goto NextPara;
                                    }
                                    else if (P.InnerText.Replace(" ", "").StartsWith("((Spre"))
                                    {
                                        bhinsprestyle = true;
                                        P.ParagraphProperties.ParagraphStyleId.Val = "Hinweis";
                                        var newPstart = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "Sonder01Anfang" }));
                                        var run = new Run(new Text() { Text = "Sonder01 Anfang" });
                                        newPstart.Append(run);
                                        P.InsertBeforeSelf(newPstart);
                                        updateRun(P);
                                        goto NextPara;
                                    }
                                    else if (P.InnerText.Replace(" ", "").StartsWith("((Tip"))
                                    {
                                        bhintipstyle = true;
                                        P.ParagraphProperties.ParagraphStyleId.Val = "Hinweis";
                                        var newPstart = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "UebungAnfang" }));
                                        var run = new Run(new Text() { Text = "Uebung Anfang" });
                                        newPstart.Append(run);
                                        P.InsertBeforeSelf(newPstart);
                                        updateRun(P);
                                        goto NextPara;
                                    }
                                    else if (P.InnerText.Replace(" ", "").StartsWith("((Abbildung"))
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "Hinweis";
                                    }
                                    else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "BullList" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "DashList"/*|| P.ParagraphProperties.ParagraphStyleId.Val == "NumList"*/)
                                    {
                                        //if (P.ParagraphProperties == null)
                                        //{
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "Aufz1-Punkt" });
                                        //}
                                        //else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId == null)
                                        //{
                                        //    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId() { Val = "Aufz1-Punkt" };
                                        //}
                                        //else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                                        //{
                                        //    P.ParagraphProperties.ParagraphStyleId.Val= "Aufz1-Punkt";
                                        //}
                                    }
                                    else if (P.ParagraphProperties.ParagraphStyleId.Val == "BodyA" || P.ParagraphProperties.ParagraphStyleId.Val == "Quote" || P.ParagraphProperties.ParagraphStyleId.Val == "PlainText" || P.ParagraphProperties.ParagraphStyleId.Val == "NumList")
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "GT" });
                                    }
                                    else if (P.ParagraphProperties.ParagraphStyleId.Val == "FTN")
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "EN" });

                                        //P.ParagraphProperties.ParagraphStyleId.Val = "EN";
                                    }
                                    updateRun(P);
                                }
                            }

                        }
                    }
                    NextPara: { };
                }

                D.Save();
            }

            return true;
        }
        private static bool CheckifParaStartWithNumber(IEnumerable<Run> RunColl)
        {
            foreach (Run R in RunColl.ToList())
            {
                string strParaText = null;

                if (R.HasChildren == true)
                {
                    foreach (Text T in R.Descendants<Text>().ToList())
                    {
                        strParaText += T.Text;

                        string strSearchRegEx = null;
                        strSearchRegEx = null;

                        strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}?\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return true;
                            }
                        }

                        strSearchRegEx = @"^[0-9]{1,}\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }
        private static void updateParaPropertiesWithBasedOnStyle(ParagraphStyleId PS, ParagraphProperties Pp, string strBasedOnStyle)
        {
            if (GlobalMethods.StyleList.Count > 0)
            {
                string key = strBasedOnStyle;
                List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                if (mystyle.Count > 0)
                {
                    if (mystyle[0].StyleParagraphProperties != null)
                    {
                        if (mystyle[0].StyleParagraphProperties.Indentation != null)
                        {
                            if (((ParagraphProperties)PS.Parent).Indentation == null)
                            {
                                GlobalMethods.bIndentation = true;
                                GlobalMethods.bLeftIndentation = true;
                                GlobalMethods.bHangingIndentation = true;
                                GlobalMethods.bFirstLineIndentation = true;

                                Pp.Indentation = new Indentation();
                            }

                            if (mystyle[0].StyleParagraphProperties.Indentation.Left != null)
                            {
                                if (Pp.Indentation.Left == null) // || Pp.Indentation.Left == ""
                                {
                                    GlobalMethods.bLeftIndentation = true;
                                    Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Left.Value;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.Indentation.Hanging != null)
                            {
                                if (Pp.Indentation.Hanging == null) //  || Pp.Indentation.Hanging == ""
                                {
                                    GlobalMethods.bHangingIndentation = true;
                                    Pp.Indentation.Hanging = mystyle[0].StyleParagraphProperties.Indentation.Hanging.Value;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.Indentation.FirstLine != null)
                            {
                                if (Pp.Indentation.FirstLine == null) //  || Pp.Indentation.FirstLine == ""
                                {
                                    GlobalMethods.bFirstLineIndentation = true;
                                    Pp.Indentation.FirstLine = mystyle[0].StyleParagraphProperties.Indentation.FirstLine.Value;
                                }
                            }
                        }

                        if (mystyle[0].StyleParagraphProperties.TextAlignment != null)
                        {
                            if (Pp.TextAlignment == null)
                            {
                                GlobalMethods.bTextAlignment = true;
                                Pp.TextAlignment = new TextAlignment();
                                Pp.TextAlignment.Val = mystyle[0].StyleParagraphProperties.TextAlignment.Val;
                            }
                        }

                        if (mystyle[0].StyleParagraphProperties.Justification != null)
                        {
                            if (((ParagraphProperties)PS.Parent).Justification == null)
                            {
                                GlobalMethods.bJustification = true;
                                Pp.Justification = new Justification();
                                Pp.Justification.Val = mystyle[0].StyleParagraphProperties.Justification.Val;
                            }
                        }


                        GlobalMethods.bParagraphBorders = false;
                        GlobalMethods.bLeftBorder = false;
                        GlobalMethods.bTopBorder = false;
                        GlobalMethods.bRightBorder = false;
                        GlobalMethods.bBottomBorder = false;
                        GlobalMethods.bBetweenBorder = false;
                        GlobalMethods.bBarBorder = false;

                        if (mystyle[0].StyleParagraphProperties.ParagraphBorders != null)
                        {
                            if (Pp.ParagraphBorders == null)
                            {
                                GlobalMethods.bParagraphBorders = true;
                                GlobalMethods.bLeftBorder = true;
                                GlobalMethods.bTopBorder = true;
                                GlobalMethods.bRightBorder = true;
                                GlobalMethods.bBottomBorder = true;
                                GlobalMethods.bBetweenBorder = true;
                                GlobalMethods.bBarBorder = true;
                                Pp.ParagraphBorders = new ParagraphBorders();
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder != null)
                            {
                                if (Pp.ParagraphBorders.LeftBorder == null)
                                {
                                    Pp.ParagraphBorders.LeftBorder = new LeftBorder();
                                }

                                if (Pp.ParagraphBorders.LeftBorder.Val == null || Pp.ParagraphBorders.LeftBorder.Val == "")
                                {
                                    GlobalMethods.bLeftBorder = true;
                                    Pp.ParagraphBorders.LeftBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder != null)
                            {
                                if (Pp.ParagraphBorders.TopBorder == null)
                                {
                                    Pp.ParagraphBorders.TopBorder = new TopBorder();
                                }

                                if (Pp.ParagraphBorders.TopBorder.Val == null || Pp.ParagraphBorders.TopBorder.Val == "")
                                {
                                    GlobalMethods.bTopBorder = true;

                                    Pp.ParagraphBorders.TopBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder != null)
                            {
                                if (Pp.ParagraphBorders.RightBorder == null)
                                {
                                    Pp.ParagraphBorders.RightBorder = new RightBorder();
                                }

                                if (Pp.ParagraphBorders.RightBorder.Val == null || Pp.ParagraphBorders.RightBorder.Val == "")
                                {
                                    GlobalMethods.bRightBorder = true;
                                    Pp.ParagraphBorders.RightBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder != null)
                            {
                                if (Pp.ParagraphBorders.BottomBorder == null)
                                {
                                    Pp.ParagraphBorders.BottomBorder = new BottomBorder();
                                }

                                if (Pp.ParagraphBorders.BottomBorder.Val == null || Pp.ParagraphBorders.BottomBorder.Val == "")
                                {
                                    GlobalMethods.bBottomBorder = true;

                                    Pp.ParagraphBorders.BottomBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder != null)
                            {
                                if (Pp.ParagraphBorders.BetweenBorder == null)
                                {
                                    Pp.ParagraphBorders.BetweenBorder = new BetweenBorder();
                                }

                                if (Pp.ParagraphBorders.BetweenBorder.Val == null || Pp.ParagraphBorders.BetweenBorder.Val == "")
                                {
                                    GlobalMethods.bBetweenBorder = true;

                                    Pp.ParagraphBorders.BetweenBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder != null)
                            {
                                if (Pp.ParagraphBorders.BarBorder == null)
                                {
                                    Pp.ParagraphBorders.BarBorder = new BarBorder();
                                }

                                if (Pp.ParagraphBorders.BarBorder.Val == null || Pp.ParagraphBorders.BarBorder.Val == "")
                                {
                                    GlobalMethods.bBarBorder = true;

                                    Pp.ParagraphBorders.BarBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder.Val;
                                }
                            }
                        }
                    }

                    if (mystyle[0].StyleRunProperties != null)
                    {
                        if (PS.Parent.Parent != null)
                        {
                            foreach (Run R in PS.Parent.Parent.Descendants<Run>().ToList())
                            {
                                if (R.RunProperties == null)
                                {
                                    // Create a new Run Properties
                                    R.RunProperties = new RunProperties();

                                    GlobalMethods.bBold = true;
                                    GlobalMethods.bCaps = true;
                                    GlobalMethods.bEmphasis = true;
                                    GlobalMethods.bItalic = true;
                                    GlobalMethods.bSmallCaps = true;
                                    GlobalMethods.bUnderline = true;
                                    GlobalMethods.bStrike = true;
                                    GlobalMethods.bDoubleStrike = true;
                                }

                                if (R.RunProperties.Bold == null)
                                {
                                    GlobalMethods.bBold = true;

                                    if (mystyle[0].StyleRunProperties.Bold != null)
                                    {
                                        R.RunProperties.Bold = new Bold();
                                        R.RunProperties.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                    }
                                }

                                if (R.RunProperties.Caps == null)
                                {
                                    GlobalMethods.bCaps = true;

                                    if (mystyle[0].StyleRunProperties.Caps != null)
                                    {
                                        R.RunProperties.Caps = new Caps();
                                        R.RunProperties.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                    }
                                }

                                if (R.RunProperties.Emphasis == null)
                                {
                                    GlobalMethods.bEmphasis = true;

                                    if (mystyle[0].StyleRunProperties.Emphasis != null)
                                    {
                                        R.RunProperties.Emphasis = new Emphasis();
                                        R.RunProperties.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                    }
                                }

                                if (R.RunProperties.Italic == null)
                                {
                                    GlobalMethods.bItalic = true;

                                    if (mystyle[0].StyleRunProperties.Italic != null)
                                    {
                                        R.RunProperties.Italic = new Italic();
                                        R.RunProperties.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                    }
                                }

                                if (R.RunProperties.SmallCaps == null)
                                {
                                    GlobalMethods.bSmallCaps = true;

                                    if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                    {
                                        R.RunProperties.SmallCaps = new SmallCaps();
                                        R.RunProperties.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                    }
                                }

                                if (R.RunProperties.Underline == null)
                                {
                                    GlobalMethods.bUnderline = true;

                                    if (mystyle[0].StyleRunProperties.Underline != null)
                                    {
                                        R.RunProperties.Underline = new Underline();
                                        R.RunProperties.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                    }
                                }

                                if (R.RunProperties.Strike == null)
                                {
                                    GlobalMethods.bStrike = true;

                                    if (mystyle[0].StyleRunProperties.Strike != null)
                                    {
                                        R.RunProperties.Strike = new Strike();
                                        R.RunProperties.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                    }
                                }

                                if (R.RunProperties.DoubleStrike == null)
                                {
                                    GlobalMethods.bDoubleStrike = true;
                                    if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                    {
                                        R.RunProperties.DoubleStrike = new DoubleStrike();
                                        R.RunProperties.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private static void updateCharPropertiesWithBasedOnStyle(RunStyle PS, RunProperties Rp, string strBasedOnStyle)
        {
            if (GlobalMethods.StyleList.Count > 0)
            {
                string key = strBasedOnStyle;
                List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                if (mystyle.Count > 0)
                {
                    if (mystyle[0].StyleRunProperties != null)
                    {
                        if (PS.Parent.Parent != null)
                        {
                            if (Rp == null)
                            {
                                // Create a new Run Properties
                                Rp = new RunProperties();
                            }

                            //27-07-2018 Addded By Karan Start
                            if (Rp.Shading == null)
                            {
                                GlobalMethods.bshading = true;
                                if (mystyle[0].StyleRunProperties.Shading != null)
                                {
                                    Rp.Shading = new Shading();
                                    Rp.Shading.Val = mystyle[0].StyleRunProperties.Shading.Val;
                                }
                            }

                            if (Rp.FontSize == null)
                            {
                                GlobalMethods.bfontsize = true;
                                if (mystyle[0].StyleRunProperties.FontSize != null)
                                {
                                    Rp.FontSize = new FontSize();
                                    Rp.FontSize.Val = mystyle[0].StyleRunProperties.FontSize.Val;
                                }
                            }
                            //27-07-2018 Addded By Karan End

                            if (Rp.VerticalTextAlignment == null)
                            {
                                GlobalMethods.bVertAlignment = true;
                                if (mystyle[0].StyleRunProperties.VerticalTextAlignment != null)
                                {
                                    Rp.VerticalTextAlignment = new VerticalTextAlignment();
                                    Rp.VerticalTextAlignment.Val = mystyle[0].StyleRunProperties.VerticalTextAlignment.Val;
                                }
                            }


                            if (Rp.Bold == null)
                            {
                                GlobalMethods.bBold = true;

                                if (mystyle[0].StyleRunProperties.Bold != null)
                                {
                                    if (mystyle[0].StyleRunProperties.Bold.Val != null)
                                    {
                                        Rp.Bold = new Bold();
                                        Rp.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                    }
                                    else
                                    {
                                        Rp.Bold = new Bold();
                                    }
                                }
                            }

                            if (Rp.Caps == null)
                            {
                                GlobalMethods.bCaps = true;

                                if (mystyle[0].StyleRunProperties.Caps != null)
                                {
                                    Rp.Caps = new Caps();
                                    Rp.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                }
                            }

                            if (Rp.Emphasis == null)
                            {
                                GlobalMethods.bEmphasis = true;

                                if (mystyle[0].StyleRunProperties.Emphasis != null)
                                {
                                    Rp.Emphasis = new Emphasis();
                                    Rp.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                }
                            }

                            if (Rp.Italic == null)
                            {
                                GlobalMethods.bItalic = true;

                                if (mystyle[0].StyleRunProperties.Italic != null)
                                {
                                    Rp.Italic = new Italic();
                                    Rp.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                }
                            }

                            if (Rp.SmallCaps == null)
                            {
                                GlobalMethods.bSmallCaps = true;

                                if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                {
                                    Rp.SmallCaps = new SmallCaps();
                                    Rp.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                }
                            }

                            if (Rp.Underline == null)
                            {
                                GlobalMethods.bUnderline = true;

                                if (mystyle[0].StyleRunProperties.Underline != null)
                                {
                                    Rp.Underline = new Underline();
                                    Rp.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                }
                            }

                            if (Rp.Strike == null)
                            {
                                GlobalMethods.bStrike = true;

                                if (mystyle[0].StyleRunProperties.Strike != null)
                                {
                                    Rp.Strike = new Strike();
                                    Rp.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                }
                            }

                            if (Rp.DoubleStrike == null)
                            {
                                GlobalMethods.bDoubleStrike = true;
                                if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                {
                                    Rp.DoubleStrike = new DoubleStrike();
                                    Rp.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                }
                            }

                            if (Rp.Border == null)
                            {
                                GlobalMethods.bCharBorder = true;
                                if (mystyle[0].StyleRunProperties.Border != null)
                                {
                                    Rp.Border = new Border();
                                    Rp.Border.Val = mystyle[0].StyleRunProperties.Border.Val;
                                }
                            }

                            if (Rp.Color == null)
                            {
                                GlobalMethods.bCharColor = true;
                                if (mystyle[0].StyleRunProperties.Color != null)
                                {
                                    Rp.Color = new Color();
                                    Rp.Color.Val = mystyle[0].StyleRunProperties.Color.Val;
                                }
                            }

                        }
                    }
                }
            }
        }

        public static void updateRun(Paragraph P)
        {
            foreach (Run R in P.Descendants<Run>().ToList())
            {
                int tcnt = 0;
                foreach (Text T in R.Descendants<Text>().ToList())
                {
                    tcnt++;
                    if (P.InnerText.Replace(" ", "").StartsWith("((Ü") || P.InnerText.Replace(" ", "").StartsWith("((U") || P.InnerText.Replace(" ", "").StartsWith("((4"))
                    {
                        if (T.Text.Trim().StartsWith("(("))
                        {
                            T.Text = Regex.Replace(T.Text, "[((]+Ü+[0-9]+[))]+|[((]+Ü+[0-9]+[)]+|[((]+U+[0-9]+[))]+|[((]+[0-9]+[))]+", "").Trim();
                        }
                    }
                    if (T.Text.Contains("„") || T.Text.Contains("”"))
                    {
                        T.Text = T.Text.Replace("„", "»").Replace("”", "«").Replace("”", "«").Replace("“", "«");
                    }
                    if (T.Text.Contains("●") || T.Text.Contains("-"))
                    {
                        T.Text = T.Text.TrimStart('●').TrimStart('-').TrimStart();
                    }
                    if (Regex.Match(T.Text, @"^[0-9]+\.").Success && P.ParagraphProperties.ParagraphStyleId.Val == "Aufz1-Punkt")
                    {
                        T.Text = Regex.Replace(T.Text, @"^[0-9]+\.", "").Trim();
                    }
                    if (P.ParagraphProperties.ParagraphStyleId.Val == "EN" && tcnt == 1)
                    {
                        T.Text = T.Text.TrimStart();
                    }
                    if (P.InnerText.Replace(" ", "").StartsWith("((Abbildung") && T.Text.StartsWith("(("))
                    {
                        T.Text = "###" + T.Text + "###";
                    }
                    //if (P.InnerText.Replace(" ", "").StartsWith("((Abbildung") && T.Text.EndsWith("))"))
                    //{
                    //    T.Text = T.Text+"###";
                    //}
                }
                if (P.ParagraphProperties.ParagraphStyleId.Val == "Aufz1-Punkt")
                {
                    foreach (TabChar T in R.Descendants<TabChar>().ToList())
                    {
                        T.Remove();
                    }
                }
                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        //if (R.RunProperties.Italic != null)
                        //{
                        //    if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null)
                        //    {
                        //        R.RunProperties.RunStyle.Val.Value = "kursiv";
                        //    }
                        //    else
                        //    {
                        //        R.RunProperties.RunStyle = new RunStyle() { Val = "kursiv" };
                        //    }
                        //}
                        if (R.RunProperties.Bold != null && R.RunProperties.Underline == null)
                        {
                            if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null)
                            {
                                R.RunProperties.RunStyle.Val.Value = "fett";
                            }
                            else
                            {
                                R.RunProperties.RunStyle = new RunStyle() { Val = "fett" };
                            }
                            R.RunProperties.Bold.Remove();
                        }
                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value.Contains("Emphasis"))
                        {

                            R.RunProperties = new RunProperties(new RunStyle() { Val = "kursiv" });
                            //R.RunProperties.RunStyle.Val.Value = "kursiv";
                            foreach (var rprele in R.RunProperties.Descendants().ToList())
                            {
                                if (rprele.LocalName == W.iCs.LocalName)
                                {
                                    rprele.Remove();
                                }
                                else if (rprele.LocalName == W.i.LocalName)
                                {
                                    rprele.Remove();
                                }
                            }
                        }
                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "citefn")
                        {
                            R.RunProperties = new RunProperties(new RunStyle() { Val = "enanker" });

                            //R.RunProperties.RunStyle.Val.Value = "enanker";
                        }
                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "label-fn")
                        {
                            // R.RunProperties.RunStyle.Val.Value = "enzeichen";
                            R.RunProperties = new RunProperties(new RunStyle() { Val = "enzeichen" });

                        }


                        var Italiccheck = false;
                        foreach (var rprele in R.RunProperties.Descendants().ToList())
                        {
                            if (rprele.LocalName == W.sz.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.szCs.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.rFonts.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.lang.LocalName)
                            {
                                rprele.Remove();
                            }
                            //else if (rprele.LocalName == W.b.LocalName)
                            //{
                            //    rprele.Remove();
                            //}
                            //else if (rprele.LocalName == W.bCs.LocalName)
                            //{
                            //    rprele.Remove();
                            //}
                            //else if (rprele.LocalName == W.iCs.LocalName)
                            //{
                            //    rprele.Remove();
                            //}
                            else if (rprele.LocalName == W.i.LocalName)
                            {
                                //rprele.Remove();
                                Italiccheck = true;
                            }
                            else if (rprele.LocalName == W.color.LocalName && Italiccheck)
                            {
                                rprele.Remove();
                                Italiccheck = false;
                            }
                            if (rprele.LocalName == W.rStyle.LocalName && R.RunProperties.RunStyle.Val.Value == "Hyperlink")
                            {
                                rprele.Remove();
                            }
                        }
                    }
                }

            }
        }



        public static void updateRunForQuote(Paragraph P)
        {
            foreach (Run R in P.Descendants<Run>().ToList())
            {

                foreach (Text T in R.Descendants<Text>().ToList())
                {
                    if (P.InnerText.Replace(" ", "").StartsWith("((Ü") || P.InnerText.Replace(" ", "").StartsWith("((U") || P.InnerText.Replace(" ", "").StartsWith("((4"))
                    {
                        if (T.Text.Trim().StartsWith("(("))
                        {
                            T.Text = Regex.Replace(T.Text, "[((]+Ü+[0-9]+[))]+|[((]+Ü+[0-9]+[)]+|[((]+U+[0-9]+[))]+|[((]+[0-9]+[))]+", "").Trim();
                        }
                    }
                    if (T.Text.Contains("„") || T.Text.Contains("”"))
                    {
                        T.Text = T.Text.Replace("„", "»").Replace("”", "«").Replace("”", "«").Replace("“", "«");
                    }
                }

                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        //if (R.RunProperties.Italic != null)
                        //{
                        //    if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null)
                        //    {
                        //        R.RunProperties.RunStyle.Val.Value = "kursiv";
                        //    }
                        //    else
                        //    {
                        //        R.RunProperties.RunStyle = new RunStyle() { Val = "kursiv" };
                        //    }
                        //}

                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value.Contains("Emphasis"))
                        {

                            R.RunProperties = new RunProperties(new RunStyle() { Val = "kursiv" });
                            //R.RunProperties.RunStyle.Val.Value = "kursiv";
                        }
                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "citefn")
                        {
                            R.RunProperties = new RunProperties(new RunStyle() { Val = "enanker" });

                            //R.RunProperties.RunStyle.Val.Value = "enanker";
                        }
                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "label-fn")
                        {
                            // R.RunProperties.RunStyle.Val.Value = "enzeichen";
                            R.RunProperties = new RunProperties(new RunStyle() { Val = "enzeichen" });

                        }



                        foreach (var rprele in R.RunProperties.Descendants().ToList())
                        {
                            if (rprele.LocalName == W.sz.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.szCs.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.rFonts.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.lang.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.b.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.bCs.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.iCs.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.i.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.color.LocalName)
                            {
                                rprele.Remove();
                            }
                            if (rprele.LocalName == W.rStyle.LocalName && R.RunProperties.RunStyle.Val.Value == "Hyperlink")
                            {
                                rprele.Remove();
                            }
                        }
                    }
                }
            }
        }


        public static void updateRunTOC(Paragraph P)
        {
            foreach (Run R in P.Descendants<Run>().ToList())
            {

                foreach (Text T in R.Descendants<Text>().ToList())
                {

                    if (T.Text.Contains("„") || T.Text.Contains("”"))
                    {
                        T.Text = T.Text.Replace("„", "»").Replace("”", "«").Replace("”", "«").Replace("“", "«");
                    }
                }

                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        //if (R.RunProperties.Italic != null)
                        //{
                        //    if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null)
                        //    {
                        //        R.RunProperties.RunStyle.Val.Value = "kursiv";
                        //    }
                        //    else
                        //    {
                        //        R.RunProperties.RunStyle = new RunStyle() { Val = "kursiv" };
                        //    }
                        //}
                        if (R.RunProperties.Bold != null && R.RunProperties.Underline == null)
                        {
                            if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null)
                            {
                                R.RunProperties.RunStyle.Val.Value = "fett";
                            }
                            else
                            {
                                R.RunProperties.RunStyle = new RunStyle() { Val = "fett" };
                            }
                            R.RunProperties.Bold.Remove();
                        }
                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value.Contains("Emphasis"))
                        {

                            R.RunProperties = new RunProperties(new RunStyle() { Val = "kursiv" });

                            //R.RunProperties.RunStyle.Val.Value = "kursiv";
                        }
                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "citefn")
                        {
                            R.RunProperties = new RunProperties(new RunStyle() { Val = "enanker" });

                            //R.RunProperties.RunStyle.Val.Value = "enanker";
                        }
                        if (R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "label-fn")
                        {
                            // R.RunProperties.RunStyle.Val.Value = "enzeichen";
                            R.RunProperties = new RunProperties(new RunStyle() { Val = "enzeichen" });

                        }

                        foreach (var rprele in R.RunProperties.Descendants().ToList())
                        {
                            if (rprele.LocalName == W.sz.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.szCs.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.rFonts.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.lang.LocalName)
                            {
                                rprele.Remove();
                            }

                            else if (rprele.LocalName == W.i.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.iCs.LocalName)
                            {
                                rprele.Remove();
                            }
                            else if (rprele.LocalName == W.color.LocalName)
                            {
                                rprele.Remove();
                            }
                        }
                    }
                }
            }
        }

        private static void createfootnote(string newDoc)
        {
            using (WordprocessingDocument myDoc = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart mainPart = myDoc.MainDocumentPart;
                var endnotePart = mainPart.AddNewPart<EndnotesPart>();
                endnotePart.Endnotes = new Endnotes();

                Document D = myDoc.MainDocumentPart.Document;
                int ftncnt = 0;

                //var cn = D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList().Where(x => x.ParagraphProperties.ParagraphStyleId.Val == "EN" && Regex.Match(x.InnerText,"^[0-9]+").Success).ToList();

                foreach (DocumentFormat.OpenXml.Wordprocessing.Paragraph P in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                {
                    if (P.ParagraphProperties.ParagraphStyleId == null)
                    {
                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "GT" });
                        updateRun(P);
                    }
                    else if (P.ParagraphProperties.ParagraphStyleId.Val == "EN" && Regex.Match(P.InnerText, "^[0-9]+").Success)
                    {

                        ftncnt++;

                        if (ftncnt == 1)
                        {
                            var newP = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "U1-neuseitig" }));
                            var run = new Run(new Text() { Text = "Anmerkungen" });
                            newP.Append(run);
                            P.InsertBeforeSelf(newP);
                        }
                        // ADD THE FOOTNOTE
                        var endnote = new Endnote();
                        endnote.Id = ftncnt;
                        updateRun(P);
                        endnote.Append(P.CloneNode(true));


                        if (P.NextSibling() != null && P.NextSibling<Paragraph>() != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val == "EN" && !Regex.Match(P.NextSibling<Paragraph>().InnerText, "^[0-9]+").Success)
                        {
                            endnote.Append(P.NextSibling<Paragraph>().CloneNode(true));
                        }
                        endnotePart.Endnotes.Append(endnote);
                        P.Remove();
                    }
                    else if (P.ParagraphProperties.ParagraphStyleId.Val == "EN")
                    {

                        P.Remove();
                    }
                    else
                    {
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {

                            if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val == "enanker")
                            {
                                // ADD THE FOOTNOTE REFERENCE
                                var fref = new EndnoteReference();
                                fref.Id = Convert.ToInt32(R.InnerText.ToString());
                                R.Append(fref);
                                if (R.Descendants<Text>().Count() > 0)
                                {
                                    R.Descendants<Text>().FirstOrDefault().Remove();
                                }

                                if (R.PreviousSibling() != null && R.PreviousSibling<Run>() != null && R.PreviousSibling<Run>().InnerText.Trim() == "")
                                {
                                    R.PreviousSibling<Run>().Remove();
                                }
                                if (R.PreviousSibling() != null && R.PreviousSibling<Run>() != null && R.PreviousSibling<Run>().InnerText.EndsWith(" "))
                                {
                                    R.PreviousSibling<Run>().Descendants<Text>().LastOrDefault().Text = R.PreviousSibling<Run>().Descendants<Text>().LastOrDefault().Text.TrimEnd();
                                }
                            }
                        }

                    }
                }

                if (D.Descendants<SectionProperties>().ToList().Count > 0)
                {
                    var endnoteproperties = new EndnoteProperties(new NumberingFormat() { Val = NumberFormatValues.Decimal });

                    D.Descendants<SectionProperties>().ToList().LastOrDefault().Append(endnoteproperties);

                }

                D.Save();


            }
        }

        public static void ConvertSoftEnterToHardEnters(string wordFilePath)
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        r.Find.Execute("^l", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "^p", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        public static void Remove3CMStylesPart(string fileName, Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> RandomhouseStyles)
        {
            try
            {
                // Declare a variable to hold the XDocument.
                //XDocument styles = null;
                Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> StyleList = new Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style>();
                var styles = new XDocument();
                // Open the document for read access and get a reference.
                using (var document =
                    WordprocessingDocument.Open(fileName, false))
                {
                    // Get a reference to the main document part.
                    var docPart = document.MainDocumentPart;

                    Document D = docPart.Document;
                    document.MainDocumentPart.StyleDefinitionsPart.Styles.OfType<DocumentFormat.OpenXml.Wordprocessing.Style>().Select(p => p).ToList().ForEach(style =>
                    {

                        if (!RandomhouseStyles.Any(k => k.Key == style.StyleId.Value))
                        {
                            style.Remove();
                        }

                    });

                    var stylesPart = document.MainDocumentPart.StyleDefinitionsPart;

                    if (stylesPart != null)
                    {
                        using (var reader = XmlNodeReader.Create(
                          stylesPart.GetStream(FileMode.Open, FileAccess.Read)))
                        {
                            // Create the XDocument.
                            styles = XDocument.Load(reader);

                            foreach (var sty in styles.Descendants().Where(x => x.Name.LocalName == "style").ToList())
                            {
                                if (sty.Attributes().Any(x => x.Name.LocalName == "styleId"))
                                {
                                    var attvalue = sty.Attributes().Where(x => x.Name.LocalName == "styleId").FirstOrDefault().Value;
                                    if (!RandomhouseStyles.Any(k => k.Key == attvalue))
                                    {
                                        sty.Remove();
                                    }
                                    if (attvalue == "Aufz1-Punkt")
                                    {
                                        foreach (var ele in sty.Descendants().ToList())
                                        {
                                            if (ele.Name.LocalName == "numId")
                                            {
                                                ele.Attributes().Where(x => x.Name.LocalName == "val").FirstOrDefault().Value = "15";

                                            }
                                        }
                                    }
                                }
                            }
                        }

                        //if (styles != null)
                        //{
                        //    styles.Save(new StreamWriter(stylesPart.GetStream(
                        //  FileMode.Create, FileAccess.Write)));
                        //}

                        // D.Save();
                        // document.Save();
                        // StyleList = .OfType<DocumentFormat.OpenXml.Wordprocessing.Style>().Select(p => p).ToDictionary(d => d.StyleId.Value);
                    }
                    // Return the XDocument instance.

                }

                ReplaceStylesPart(fileName, styles);

                ReplaceNumberingPart(fileName);
            }
            catch (Exception ex)
            {

            }
        }

        public static void ReplaceStylesPart(string fileName, XDocument newStyles,
      bool setStylesWithEffectsPart = false)
        {
            // Open the document for write access and get a reference.
            using (var document =
                WordprocessingDocument.Open(fileName, true))
            {
                // Get a reference to the main document part.
                var docPart = document.MainDocumentPart;

                // Assign a reference to the appropriate part to the
                // stylesPart variable.
                StylesPart stylesPart = null;
                if (setStylesWithEffectsPart)
                    stylesPart = docPart.StylesWithEffectsPart;
                else
                    stylesPart = docPart.StyleDefinitionsPart;

                // If the part exists, populate it with the new styles.
                if (stylesPart != null)
                {
                    newStyles.Save(new StreamWriter(stylesPart.GetStream(
                      FileMode.Create, FileAccess.Write)));
                }
            }
        }

        public static void ReplaceNumberingPart(string fileName)
        {

            using (var document =
      WordprocessingDocument.Open(System.Configuration.ConfigurationManager.AppSettings["RandomHouseWordTemplate"], true))
            {
                // Get a reference to the main document part.
                var docPart = document.MainDocumentPart;

                // Assign a reference to the appropriate part to the
                //  NumberingDefinitionsPart variable.
                NumberingDefinitionsPart stylesPart = docPart.NumberingDefinitionsPart;

                if (stylesPart != null)
                {
                    using (var reader = XmlNodeReader.Create(
                      stylesPart.GetStream(FileMode.Open, FileAccess.Read)))
                    {
                        // Create the XDocument.
                        formating = XDocument.Load(reader);


                    }
                }
            }

            // Open the document for write access and get a reference.
            using (var document =
                WordprocessingDocument.Open(fileName, true))
            {
                // Get a reference to the main document part.
                var docPart = document.MainDocumentPart;

                // Assign a reference to the appropriate part to the
                //  NumberingDefinitionsPart variable.
                NumberingDefinitionsPart stylesPart = docPart.NumberingDefinitionsPart;
                if (stylesPart == null)
                {
                    NumberingDefinitionsPart numberingPart =
   docPart.AddNewPart<NumberingDefinitionsPart>("someUniqueIdHere");
                    Numbering element =
      new Numbering(
        new AbstractNum(
          new Level(
            new NumberingFormat() { Val = NumberFormatValues.Bullet },
            new LevelText() { Val = "·" }
          )
          { LevelIndex = 0 }
        )
        { AbstractNumberId = 1 },
        new NumberingInstance(
          new AbstractNumId() { Val = 1 }
        )
        { NumberID = 1 });

                    element.Save(numberingPart);
                    stylesPart = docPart.NumberingDefinitionsPart;
                }
                // If the part exists, populate it with the new styles.
                if (stylesPart != null)
                {
                    formating.Save(new StreamWriter(stylesPart.GetStream(
                      FileMode.Create, FileAccess.Write)));
                }
            }
        }

        public static void ReplaceStylingingPart(string fileName)
        {

            using (var document =
      WordprocessingDocument.Open(System.Configuration.ConfigurationManager.AppSettings["RandomHouseWordTemplate"], true))
            {
                // Get a reference to the main document part.
                var docPart = document.MainDocumentPart;

                // Assign a reference to the appropriate part to the
                //  NumberingDefinitionsPart variable.
                StyleDefinitionsPart stylesPart = docPart.StyleDefinitionsPart;

                if (stylesPart != null)
                {
                    using (var reader = XmlNodeReader.Create(
                      stylesPart.GetStream(FileMode.Open, FileAccess.Read)))
                    {
                        // Create the XDocument.
                        formating = XDocument.Load(reader);


                    }
                }
            }

            // Open the document for write access and get a reference.
            using (var document =
                WordprocessingDocument.Open(fileName, true))
            {
                // Get a reference to the main document part.
                var docPart = document.MainDocumentPart;

                // Assign a reference to the appropriate part to the
                //  NumberingDefinitionsPart variable.
                NumberingDefinitionsPart stylesPart = docPart.NumberingDefinitionsPart;

                // If the part exists, populate it with the new styles.
                if (stylesPart != null)
                {
                    formating.Save(new StreamWriter(stylesPart.GetStream(
                      FileMode.Create, FileAccess.Write)));
                }
            }
        }

        public static void GeneralSearchAndReplace(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {
                string strDocContent = null;

                // Read the Document Content from Word Document //
                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {
                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(ISBN)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "GT", "isbn", "", true, false, true, true, false);
                        }
                    }



                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {
                mdoc.Close();
            }
            finally
            {
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((Microsoft.Office.Interop.Word._Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    //((_Document)mdoc).Close(WdSaveOptions.wdSaveChanges, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }
        }

        public static void GenerateAutoTOC(string docPath)
        {
            var application = new Microsoft.Office.Interop.Word.Application();
            var document = application.Documents.Open(FileName: docPath);

            var tocRange = document.Range(0, 0);
            var toc = document.TablesOfContents.Add(
                Range: tocRange,
                UseHeadingStyles: true);
            toc.Update();

            var tocTitleRange = document.Range(0, 0);
            tocTitleRange.Text = "Inhaltsverzeichnis";
            tocTitleRange.InsertParagraphAfter();
            tocTitleRange.set_Style("U1-neuseitig");


            object oMissing = System.Reflection.Missing.Value;

            object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
            ((Microsoft.Office.Interop.Word._Document)document).Close(ref saveChanges, ref oMissing, ref oMissing);

            application.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(application);
        }
        private static void applyGTStyletoTOC(string newDoc)
        {
            using (WordprocessingDocument myDoc = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart mainPart = myDoc.MainDocumentPart;


                Document D = myDoc.MainDocumentPart.Document;


                //var cn = D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList().Where(x => x.ParagraphProperties.ParagraphStyleId.Val == "EN" && Regex.Match(x.InnerText,"^[0-9]+").Success).ToList();

                foreach (DocumentFormat.OpenXml.Wordprocessing.Paragraph P in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                {
                    if (P.ParagraphProperties == null && P.ParagraphProperties.ParagraphStyleId == null)
                    {
                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "GT" });
                        updateRun(P);
                    }
                    else if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.StartsWith("TOC"))
                    {
                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "GT" });
                        updateRun(P);
                    }

                }



                D.Save();


            }
        }

        public static void Addpagebreak(string newDoc)
        {
          
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (DocumentFormat.OpenXml.Wordprocessing.Paragraph P in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                {
                    if (Regex.Match(P.InnerText.Trim(), @"([((Seite]\s[0-9]+;)").Success )
                    {
                        P.ParagraphProperties.PageBreakBefore = new PageBreakBefore();
                    }
                   else if(P.InnerText.StartsWith("Sollte diese Publikation"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "ImprDisclaimer-neuseitig";
                    }
                    else if (P.InnerText.ToLower().StartsWith("www."))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "ImprGT";
                    }
                }
                D.Save();
            }
        }
    }
}
