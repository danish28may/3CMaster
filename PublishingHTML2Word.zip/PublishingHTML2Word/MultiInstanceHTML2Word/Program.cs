﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiInstancePublishingHTML2Word
{
    class Program
    {
        static void Main(string[] args)
        {
            // RandomHouseStructuring.StartConversion(@"C:\3CMAutomation\HTML2WORD\Out\3882\143_VRH_B_DiTech_Originalmanuskript-2.docx");
            
            string filepath = args[0];
            //string filepath = @"C:\3CMAutomation\HTML2WORD\Process\15964";
            //Start(filepath);
            try
            {
               Start(filepath);
            }
            catch (Exception ex)
            {
                string folderpath = filepath.Substring(filepath.LastIndexOf("\\"));

                //folderpath = folderpath.Substring(folderpath.LastIndexOf("\\"));

                string strErrorFileName = null;
                string strProcessFolder = null;

                if (GlobalMethods.StrOutFolder != null || GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder;
                    if (folderpath.StartsWith("\\"))
                        strErrorFileName = strErrorFileName + folderpath;
                    else
                        strErrorFileName = strErrorFileName + "\\" + folderpath;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    strErrorFileName = strErrorFileName + "Error.log";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine(ex.ToString());
                    sw.WriteLine("Publishing HTML2Word");
                    sw.WriteLine("Exception in Processing the document. Please consult 3CM Administrator.");
                    sw.Close();
                }

                strProcessFolder = GlobalMethods.StrProcessFolder;

                if (folderpath.StartsWith("\\"))
                    strProcessFolder = strProcessFolder + folderpath;
                else
                    strProcessFolder = strProcessFolder + "\\" + folderpath;
                if (Directory.Exists(strProcessFolder))
                {
                    Directory.Delete(strProcessFolder, true);
                }
            }
        }
        static void Start(string strDocumentName)
        {
            GlobalMethods.StrInFolder = ConfigurationManager.AppSettings.Get("HTML2WORDIN");
            GlobalMethods.StrOutFolder = ConfigurationManager.AppSettings.Get("HTML2WORDOUT");
            GlobalMethods.StrProcessFolder = ConfigurationManager.AppSettings.Get("HTML2WORDPROCESS");
            GlobalMethods.str3CMWordTemplate = ConfigurationManager.AppSettings.Get("3CMWordTemplate");
            GlobalMethods.str3cmHTMLTemplate = ConfigurationManager.AppSettings.Get("3cmHTMLTemplate");
            GlobalMethods.str3CMValidParagraphStyleConfig = ConfigurationManager.AppSettings.Get("3CMStyleValidParagraphStylesConfig");
            GlobalMethods.str3CMValidCharacterStyleConfig = ConfigurationManager.AppSettings.Get("3CMStyleValidCharacterStylesConfig");
            GlobalMethods.str3CMRemoveStylesFromTemplate = ConfigurationManager.AppSettings.Get("3CMRemoveStylesFromWordTemplate");
            object OutputFilename = null;
            ///Added by Karan on 11-09-2018 to get files from process folder start
            FileInfo ff = null;
            //DirectoryInfo Dir = new DirectoryInfo(strDocumentName.ToString());
            DirectoryInfo Dir = new DirectoryInfo(strDocumentName);
            FileInfo[] filesForProcess = Dir.GetFiles();
            foreach (var files in filesForProcess)
            {
                if (files.Extension == ".xml")
                {
                    GlobalMethods.ReadCustomPropertiesXML(files.FullName);
                }
                if (files.Extension == ".html")
                {
                    if (!files.Name.StartsWith("~$"))
                    {
                        ff = files;
                    }
                }
            }
            if (ff == null)
            {
                Console.WriteLine("Job name: " + ff.Name + " ," + "Job ID: " + ff.Directory.Name + " ," + "Processing start time:" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));

                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + Dir.Name;
                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);
                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";
                    strErrorFileName = strErrorFileName + "Error.log";
                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Document not found in HTML2WORD Input folder. Please consult 3CM Administrator.");
                    sw.Close();
                }
                // Remove the document from Process folder
                goto EndProcess;
            }
            ///Added by Karan on 11-09-2018 to get files from process folder end
            //FileInfo ff = new FileInfo(strDocumentName.ToString());//commented by Karan on 11-09-2018
            //Added by Karan on 11-09-2018 Start
            MapStylesWithWordTemplate.CheckForEquation(ff.FullName);
            string eqDirPath = ff.DirectoryName + "\\Equations";
            //GlobalMethods.strImagePath.ToString().Contains("_W_") condition added by vikas on 13-03-2021 for not required to run math equation for content wordtoword conversion
            if (!GlobalMethods.strImagePath.Contains("_W_") && (!GlobalMethods.strImagePath.Contains("\\CSU\\") && !GlobalMethods.strImagePath.Contains("\\UTS\\") && !GlobalMethods.strImagePath.Contains("\\QUT\\")))
            {
                if (Directory.Exists(eqDirPath))
                {
                    string strJobTransID = ff.DirectoryName.Substring(ff.DirectoryName.LastIndexOf("\\") + 1);
                    Process pr = new Process();
                    pr.StartInfo.Arguments = ff.DirectoryName + " MML " + strJobTransID;
                  //  pr.StartInfo.Arguments = "TXT";
                   // pr.StartInfo.CreateNoWindow = true;
                    pr.StartInfo.FileName = "ConvertEquations.exe";
                    pr.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
                    pr.Start();
                    pr.WaitForExit();
                    DirectoryInfo p = new DirectoryInfo(eqDirPath + "\\");
                    //DirectoryInfo path = new DirectoryInfo(GlobalMethods.strImagePath + "\\");
                    //FileInfo[] p1 = p.GetFiles();
                    //foreach (var item in p1)
                    //{
                    //    try
                    //    {
                    //        if (Directory.Exists(GlobalMethods.strImagePath + "\\"))
                    //        {

                    //            File.Copy(item.FullName, path + "Equations" + "\\" + item.Name, true);
                    //        }
                    //    }
                    //    catch (Exception ex)
                    //    {

                    //    }
                    //}
                    ///////////////////////////////////////////////////////////////
                    DirectoryInfo pa = new DirectoryInfo(eqDirPath + "\\");
                    DirectoryInfo path = new DirectoryInfo(GlobalMethods.strImagePath + "\\Equations");
                    FileInfo[] p1 = pa.GetFiles();
                    foreach (var item in p1)
                    {
                        try
                        {
                            // Combine the source and destination paths
                            string sourceFilePath = item.FullName;
                            string destinationFilePath = Path.Combine(path.FullName, item.Name);

                            if (Directory.Exists(path.FullName))
                            {
                                // Check if the destination file already exists
                                if (File.Exists(destinationFilePath))
                                {
                                    // Delete the existing destination file
                                    File.Delete(destinationFilePath);
                                }
                                // Copy the file to the destination with the same name
                                File.Copy(sourceFilePath, destinationFilePath);
                            }
                        }
                        catch (Exception ex)
                        {
                            // Handle exceptions if necessary
                        }
                    }
                }
            }
            //Added by Karan on 11-09-2018 End
            ///Added by Manish on 19-06-2018
            try
            {

                if (GlobalMethods.strClientName.ToLower() == "sage")//////Developer Name:Vikas More, Date:09-12-2020,Requirement:TI style required inplace of AT style for article title as per 3CM requirement sage reqired At style
                {
                    MapStylesWithWordTemplate.ATtoTIstyleChange(ff.FullName);
                }
            }
            catch (Exception e)
            {

            }
            MapStylesWithWordTemplate.ChangeAllInsertDeleteSpan(ff.FullName);

            MapStylesWithWordTemplate.removeAuthorQueryHeading(ff.FullName);    //Developer name:Priyanka Vishwakarma ,Date:23_09_2019 ,Requirement:Remove Author Query heading ,Integrated by:Vikas sir.

            MapStylesWithWordTemplate.ReadWordHTMLTemplateAndStoreInHead(ff.FullName, GlobalMethods.str3cmHTMLTemplate);
            MapStylesWithWordTemplate.ReadWordHTMLStyle(ff.FullName);

            MapStylesWithWordTemplate.ReadCommentFromHtmlAndRemove(ff.FullName); //Developer Name:Priyanka Vishwakarma ,Date:13_08_2019, Requirement: Table converted into text because of comments, Integrated by:Vikas sir.


            MapStylesWithWordTemplate.ReadCommentTextBeforeConvet(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add all comments in list before html to word conversion,Integrated by:Vikas sir.
            MapStylesWithWordTemplate.Remove3CMProofingCommentimgtag(ff.FullName);///Added by vikas on 09-10-2020
            MapStylesWithWordTemplate.CheckClosingifTaginComments(ff.FullName);//Developer Name: Priyanka Vishwakarma,Date: 25-11-2021, Add function for adding comment endif in author query when endif comment missing after anchor tag
            MapStylesWithWordTemplate.RemoveanchortagandunderlinefromDOI(ff.FullName); //Developer Name:Priyanka Vishwakarma,Date:27-11-2021, Requirement: remove anchor tag and u tag from doi 
           
            //MapStylesWithWordTemplate.ReplaceSpantagtoSupSub(ff.FullName);

            MapStylesWithWordTemplate.ReplaceSpantagtoSupSubBI(ff.FullName);

            try
            {
                if (GlobalMethods.strClientName.ToLower() == "sage" && GlobalMethods.strCleanupStatus.ToLower() == "notdone")////added by vikas on 18-10-2020
                {
                    MapStylesWithWordTemplate.CreationofAFFLCORRandAUForSage(ff.FullName);
                    MapStylesWithWordTemplate.CreationofAFFLCORRandAUForSageFootnote(ff.FullName);
                }

            }
            catch (Exception e)
            {

            }
            //added by vikas on 13-03-2021 for  content wordtoword conversion images come as its in word
            //if (GlobalMethods.strImagePath.ToString().Contains("_W_") && (GlobalMethods.strImagePath.Contains("\\CSU\\") || GlobalMethods.strImagePath.Contains("\\UTS\\") || GlobalMethods.strImagePath.Contains("\\QUT\\")) && GlobalMethods.strServiceType == "Content")
            //{
            //    ExportHTML2Word.CopyloresfolderImagestoprocessfolder(ff.FullName);
            //    OutputFilename = ExportHTML2Word.ConvertHTMLtoWord(ff.FullName);               
            //}
            //else
            //{
                OutputFilename = ExportHTML2Word.ConvertWord(ff.FullName);
            //}

            System.Threading.Thread.Sleep(3000);

            // Commented by Abhijeet on 01 April, 2018 as this function is not required now
            //string templatePath = CopyStylesFromTemplate.CopyTempTemplate(OutputFilename.ToString(), GlobalMethods.str3CMWordTemplate);

            //CopyStylesFromTemplate.ExtractStyles(OutputFilename.ToString(), templatePath);
            ////////////// Copy Styles from Word Template to the document

            if (OutputFilename != null)
            {
                if (GlobalMethods.strCleanupStatus.ToLower() == "done")
                {
                    GlobalMethods.Replaceplaceholders(OutputFilename.ToString());//Developer Name:Priyanka Vishwakarma, Date:25-11-2021 ,Remove nonbreaking space
                    MapStylesWithWordTemplate.CleanupExtraSpaces(OutputFilename.ToString());
                }

                //MapStylesWithWordTemplate.Abtxt_StyleApplied(OutputFilename.ToString());

                MapStylesWithWordTemplate.MapandApplyStyles(OutputFilename.ToString());

                MapStylesWithWordTemplate.ReplaceSpaceWithTabInListNum(OutputFilename.ToString());

                MapStylesWithWordTemplate.RemoveSpaceFromCellWithOnlySpace(OutputFilename.ToString());

                MapStylesWithWordTemplate.UpdateTableCellWidth(OutputFilename.ToString());

                // Strat New Function Added By Karan on 14-08-2018 For remove space in Start or End Styles
                MapStylesWithWordTemplate.RemoveTextFromStartOrEndStyles(OutputFilename.ToString());
                //End New Function Added By Karan on 14-08-2018 For remove space in Start or End Styles 

                MapStylesWithWordTemplate.GetCommentsAfterDocument(OutputFilename.ToString());//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add all comments in list after html to word conversion,Integrated by:Vikas sir.                              
                MapStylesWithWordTemplate.checkMissingComment(OutputFilename.ToString(), GlobalMethods.beforecmt, GlobalMethods.Aftercmt);//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add comment in word document if any query is missing after conversion process of html to word. ,Integrated by:Vikas sir.

                if (GlobalMethods.strClientName == "RandomHouse" && GlobalMethods.strProcessingType != null && GlobalMethods.strProcessingType == "readyforeditinghtmltoword")
                {
                    RandomHouseStructuring.StartConversion(OutputFilename.ToString());
                }
                MapStylesWithWordTemplate.AddNewJournalTitle(OutputFilename.ToString()); //Developer name :Priyanka Vishwakarma. Date:10-06-2021, Requirement:Add Journal title in text file
                

                if (GlobalMethods.strPreprocessing.ToLower() == "no" & GlobalMethods.strClientName.ToLower()=="ssllc")  //Developer Name:Priyanka Vishwakarma,Date:4-2-2022, Requirement: Add Images in word file for SSLLC
                {                    
                    MapStylesWithWordTemplate.InsertImageInWordFile(OutputFilename.ToString());                    
                }
               

                if (File.Exists(OutputFilename.ToString()))
                {
                    // Move the processed document to out folder
                    FileInfo fout = new FileInfo(OutputFilename.ToString());

                    string strParentDirectory = fout.Directory.Name;
                    string outfile = null;

                    outfile = fout.Name;

                    if (Directory.Exists(GlobalMethods.StrOutFolder + "\\" + strParentDirectory) == false)
                    {
                        Directory.CreateDirectory(GlobalMethods.StrOutFolder + "\\" + strParentDirectory);
                    }

                    outfile = GlobalMethods.StrOutFolder + "\\" + strParentDirectory + "\\" + outfile;
                    System.Threading.Thread.Sleep(500);///// pause for process completion
                    // On completion copy the output file in out folder
                    if (Directory.Exists(GlobalMethods.StrOutFolder + "\\" + strParentDirectory))
                        File.Copy(OutputFilename.ToString(), outfile, true);
                    else
                    {
                        Directory.CreateDirectory(GlobalMethods.StrOutFolder + "\\" + strParentDirectory);
                        File.Copy(OutputFilename.ToString(), outfile, true);
                    }
                    if (new DirectoryInfo(fout.Directory.FullName).GetFiles().Count() > 1)
                    {
                        foreach (var file in new DirectoryInfo(fout.Directory.FullName).GetFiles())
                        {
                            if (file.Name != outfile && file.Extension == ".docx")
                            {
                                File.Copy(file.FullName, GlobalMethods.StrOutFolder + "\\" + strParentDirectory + "\\" + file.Name, true);
                                file.Delete();
                            }
                        }
                    }

                    // Delete the files from the Process folder

                    fout.Delete();

                    // Remove unnecessary files and folders from out folder

                    Directory.Delete(fout.Directory.FullName, true);

                    System.Threading.Thread.Sleep(3000);
                }
            }
        EndProcess:
            {
                if (Directory.Exists(GlobalMethods.StrProcessFolder + "\\" + Dir.Name))
                {
                    Directory.Delete(GlobalMethods.StrProcessFolder + "\\" + Dir.Name);
                }
            }

        }
    }
}
