﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Office.Interop.Word;
using System.IO;
using System.Runtime.InteropServices;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;

namespace MultiInstancePublishingHTML2Word
{
    class ExportHTML2Word
    {
        public static object ConvertWord(string strHTMLPath)
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)strHTMLPath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        WdSaveFormat format = WdSaveFormat.wdFormatXMLDocument;
                        doc.Activate();
                        outputFileName = strHTMLPath.Replace(".html", ".docx");
                        object fileFormat = format;
                        doc.WebOptions.Encoding = Microsoft.Office.Core.MsoEncoding.msoEncodingUTF8;
                        doc.SaveAs(ref outputFileName,
                                   ref fileFormat, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                        if (doc != null) Marshal.ReleaseComObject(doc);
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    if (word != null) Marshal.ReleaseComObject(word);
                    word = null;
                }

                return outputFileName;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public static void CopyloresfolderImagestoprocessfolder(string strDocPath)
        {
            if (!Directory.Exists(new FileInfo(strDocPath).Directory.FullName + "\\" + Path.GetFileNameWithoutExtension(strDocPath) + "_files"))
            {
                Directory.CreateDirectory(new FileInfo(strDocPath).Directory.FullName + "\\" + Path.GetFileNameWithoutExtension(strDocPath) + "_files");
                foreach (var file in Directory.GetFiles(GlobalMethods.strImagePath))
                {
                    if (new FileInfo(file).Extension != ".xml" && new FileInfo(file).Extension != ".thmx")
                    {
                        new FileInfo(file).CopyTo(new FileInfo(strDocPath).Directory.FullName + "\\" + Path.GetFileNameWithoutExtension(strDocPath) + "_files" + "\\" + new FileInfo(file).Name, true);
                    }
                }
            }
            else
            {
                Directory.Delete(new FileInfo(strDocPath).Directory.FullName + "\\" + Path.GetFileNameWithoutExtension(strDocPath) + "_files",true);
                Directory.CreateDirectory(new FileInfo(strDocPath).Directory.FullName + "\\" + Path.GetFileNameWithoutExtension(strDocPath) + "_files");
                foreach (var file in Directory.GetFiles(GlobalMethods.strImagePath))
                {
                    if (new FileInfo(file).Extension != ".xml" && new FileInfo(file).Extension != ".thmx")
                    {
                        new FileInfo(file).CopyTo(new FileInfo(strDocPath).Directory.FullName + "\\" + Path.GetFileNameWithoutExtension(strDocPath) + "_files" + "\\" + new FileInfo(file).Name, true);
                    }
                }
            }
        }

        //public static object ConvertHTMLtoWord(string HTMLPath)
        //{
        //    const string filename = HTMLPath.Replace(".html",".docx");
        //    //Response.ContentEncoding = System.Text.Encoding.UTF7;
        //    System.Text.StringBuilder SB = new System.Text.StringBuilder();
        //    System.IO.StringWriter SW = new System.IO.StringWriter();
        //    System.Web.UI.HtmlTextWriter htmlTW = new System.Web.UI.HtmlTextWriter(SW);
        //    tbl.RenderControl(htmlTW);
        //    string strBody = "<html>" +
        //     "<body>" + "<div><b>" + htmlTW.InnerWriter.ToString() + "</b></div>" +
        //       "</body>" +
        //      "</html>";
        //    string html = strBody;

        //    if (File.Exists(filename)) File.Delete(filename);

        //    using (MemoryStream generatedDocument = new MemoryStream())
        //    {
        //        using (WordprocessingDocument package = WordprocessingDocument.Create(generatedDocument, WordprocessingDocumentType.Document))
        //        {
        //            MainDocumentPart mainPart = package.MainDocumentPart;
        //            if (mainPart == null)
        //            {
        //                mainPart = package.AddMainDocumentPart();
        //                new Document(new Body()).Save(mainPart);
        //            }

        //            HtmlConverter converter = new HtmlConverter(mainPart);
        //            converter.BaseImageUrl = new Uri("http://localhost:portnumber/");
        //            Body body = mainPart.Document.Body;

        //            var paragraphs = converter.Parse(html);
        //            for (int i = 0; i < paragraphs.Count; i++)
        //            {
        //                body.Append(paragraphs[i]);
        //            }

        //            mainPart.Document.Save();
        //        }

        //        File.WriteAllBytes(filename, generatedDocument.ToArray());
        //    }

        //    System.Diagnostics.Process.Start(filename);
        //}

        public static object ConvertHTMLtoWord(string strHTMLPath)
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)strHTMLPath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    var count = 0;
                    var imgcount = doc.InlineShapes.Count;
                    Console.WriteLine($"Shape Count = "+imgcount);
                    var imglist = new List<string>();
                    foreach(var imgfile in Directory.GetFiles(new FileInfo(strHTMLPath).Directory.FullName + "\\" + Path.GetFileNameWithoutExtension(strHTMLPath) + "_files"))
                    {
                        if(imgfile.EndsWith(".png"))
                        imglist.Add(imgfile);
                    }
                    foreach (InlineShape shape in doc.InlineShapes)
                    {
                       
                        Console.WriteLine($"Shape (width,height) = ({shape.Width},{shape.Height})");
                        Console.WriteLine($"Shape type = {shape.Type}");
                        Console.WriteLine();
                        if (shape.Type == WdInlineShapeType.wdInlineShapePicture)
                        {
                            shape.Fill.UserPicture(imglist[count]);
                        }
                        count++;
                    }



                    //doc= word.Documents.Add();
                    //foreach (var file in Directory.GetFiles(new FileInfo(strHTMLPath).Directory.FullName + "\\" + Path.GetFileNameWithoutExtension(strHTMLPath) + "_files"))
                    //{
                    //    string imagePath = file;
                    //    Range docRange = doc.Range();

                    //    // Create an InlineShape in the InlineShapes collection where the picture should be added later
                    //    // It is used to get automatically scaled sizes.
                    //    InlineShape autoScaledInlineShape = docRange.InlineShapes.AddPicture(imagePath);
                    //    float scaledWidth = autoScaledInlineShape.Width;
                    //    float scaledHeight = autoScaledInlineShape.Height;
                    //    autoScaledInlineShape.Delete();

                    //    // Create a new Shape and fill it with the picture
                    //    Shape newShape = doc.Shapes.AddShape(1, 0, 0, scaledWidth, scaledHeight);
                    //    newShape.Fill.UserPicture(imagePath);

                    //    // Convert the Shape to an InlineShape and optional disable Border
                    //    InlineShape finalInlineShape = newShape.ConvertToInlineShape();
                    //    finalInlineShape.Line.Visible = Microsoft.Office.Core.MsoTriState.msoFalse;

                    //    // Cut the range of the InlineShape to clipboard
                    //    finalInlineShape.Range.Cut();

                    //    // And paste it to the target Range
                    //    docRange.Paste();
                    //}
                    try
                    {
                        WdSaveFormat format = WdSaveFormat.wdFormatXMLDocument;
                        doc.Activate();
                        outputFileName = strHTMLPath.Replace(".html", ".docx");
                        object fileFormat = format;
                        doc.WebOptions.Encoding = Microsoft.Office.Core.MsoEncoding.msoEncodingUTF8;
                        doc.SaveAs(ref outputFileName,
                                   ref fileFormat, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                        if (doc != null) Marshal.ReleaseComObject(doc);
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    if (word != null) Marshal.ReleaseComObject(word);
                    word = null;
                }

                return outputFileName;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }

}
