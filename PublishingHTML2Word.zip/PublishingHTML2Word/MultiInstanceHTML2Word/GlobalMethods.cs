﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace MultiInstancePublishingHTML2Word
{
    class GlobalMethods
    {
        public static string StrInFolder = null;
        public static string StrOutFolder = null;
        public static string StrProcessFolder = null;

        public static string str3CMValidParagraphStyleConfig = null;
        public static string str3CMValidCharacterStyleConfig = null;
        public static string str3CMRemoveStylesFromTemplate = null;


        public static string str3CMWordTemplate = null;

        public static string str3cmHTMLTemplate = null;

        ///Added by Karan on 11-09-2018 Start
        public static string strJobTransID = null;
        public static string strDocumentType = null;
        public static string strImagePath = null;
        public static string strImageIndex = null;
        ///Added by Karan on 11-09-2018 End
        ///
        public static string strServiceType = null;/// Added by vikas on 03-02-2021
        


        ////added by vikas on 09-04-2020 for random house clinet structuring
        public static string strClientName = null; ////added by vikas on 09-04-2020
        public static string strProcessingType = null; ////added by vikas on 09-04-2020

        public static Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> StyleList;

        public static Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> StyleListRandomHouseTemplate;

        public static bool bIndentation = false;
        public static bool bLeftIndentation = false;
        public static bool bHangingIndentation = false;
        public static bool bFirstLineIndentation = false;
        public static bool bTextAlignment = false;
        public static bool bJustification = false;
        public static bool bParagraphBorders = false;

        public static bool bLeftBorder = false;
        public static bool bTopBorder = false;
        public static bool bRightBorder = false;
        public static bool bBottomBorder = false;
        public static bool bBetweenBorder = false;
        public static bool bBarBorder = false;

        public static bool bBold = false;
        public static bool bCaps = false;
        public static bool bEmphasis = false;
        public static bool bItalic = false;
        public static bool bSmallCaps = false;
        public static bool bUnderline = false;
        public static bool bStrike = false;
        public static bool bDoubleStrike = false;

        public static bool bVertAlignment = false;
        public static bool bCharBorder = false;
        public static bool bCharColor = false;

        public static bool bshading = false;
        public static bool bfontsize = false;

        public static string strCleanupStatus = null;///added on 18-10-2020
        public static string strPreprocessing = null;

        public static bool btabs = false;

        public static Microsoft.Office.Interop.Word.Application wordApp = null;


        public static List<string> beforecmt = new List<string>();//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add all comments in list before html to word conversion,Integrated by:Vikas sir.                              
        public static List<string> Aftercmt = new List<string>();//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add all comments in list after html to word conversion,Integrated by:Vikas sir. 
        public static List<string> ReadAndStoreFileValuesInArray(string StyleMappingConfigFile)
        {
            //string[] strStyleMapping = new string[1];
            List<string> strStyleMapping = new List<string>();
            strStyleMapping.Clear();

            if (File.Exists(StyleMappingConfigFile) == false)
                return strStyleMapping;

            int counter = 0;

            string strLine = null;

            StreamReader sr = new StreamReader(StyleMappingConfigFile);

            strStyleMapping.Clear();

            while ((strLine = sr.ReadLine()) != null)
            {
                if (strLine.StartsWith("//") == false)
                {
                    strStyleMapping.Add(strLine.Trim());
                    counter++;
                }
            }

            sr.Close();

            return strStyleMapping;
        }

        public static string SearchRegExPatternFirstSearchInstanceOnly(string strParaContent, string strSearchRegEx)
        {
            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strParaContent);

            if (m.Success)
            {
                return m.Value;
            }

            return null;
        }

        public static void ReadCustomPropertiesXML(string strXMLPath)
        {
            var customProperties = from custProp in XElement.Load(strXMLPath).Elements() select custProp;

            foreach (var property in customProperties)
            {
                if (property.Name.LocalName == "TransactionID")
                {
                    strJobTransID = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "DocumentType")
                {
                    strDocumentType = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ImagePath")
                {
                    strImagePath = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ImageIndex")
                {
                    strImageIndex = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ClientName")
                {
                    strClientName = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ProcessingType")
                {
                    strProcessingType = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "CleanupProcess")/////This for informs style guide code run after html convert from word added by vikas on 11-09-2020
                {
                    strCleanupStatus = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "Preprocessing")/////This for informs style guide code run after html convert from word added by vikas on 11-09-2020
                {
                    strPreprocessing = property.Value;
                    continue;
                }
                //"Preprocessing"
                if (property.Name.LocalName == "ServiceType")/////Added by vikas on 03-02-2021
                {
                    strServiceType = property.Value;
                    continue;
                }
            }
            if (strCleanupStatus == null)
            {
                strCleanupStatus = "NotDone";
            }

        }

        public static string RegExSearch(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                return m.Value;
            }

            return "";
        }
        public static bool ValidateRegEx(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                return true;
            }

            return false;
        }
        public static Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> ExtractStylesPart(string fileName, bool getStylesWithEffectsPart = true)
        {
            // Declare a variable to hold the XDocument.
            //XDocument styles = null;
            Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> StyleList = new Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style>();

            // Open the document for read access and get a reference.
            using (var document =
                WordprocessingDocument.Open(fileName, false))
            {
                // Get a reference to the main document part.
                var docPart = document.MainDocumentPart;

                StyleList = document.MainDocumentPart.StyleDefinitionsPart.Styles.OfType<DocumentFormat.OpenXml.Wordprocessing.Style>().Select(p => p).ToDictionary(d => d.StyleId.Value);
            }
            // Return the XDocument instance.
            return StyleList;
        }
        public static bool SearchAndReplace(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Microsoft.Office.Interop.Word.Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;

            if (strSearchText != "")
                rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            if (bReplaceAll == true && bGeneralCrosslink == true)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            if (bGeneralCrosslink == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
            }

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    do
                    {
                        if (rngDoc.ParagraphStyle != null)
                        {
                            if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC" && rngDoc.ParagraphStyle.NameLocal != "BoxStart")
                            {
                                if (strReplaceCharStyle != "")
                                {
                                    int nBold = rngDoc.Bold;
                                    int nItalic = rngDoc.Italic;

                                    rngDoc.set_Style(strReplaceCharStyle);

                                    rngDoc.Bold = nBold;
                                    rngDoc.Italic = nItalic;

                                    if (strReplaceText != "")
                                        rngDoc.Find.Execute(Replace: replaceOne);
                                }
                            }

                            //if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                            //{
                            //    rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                            //}
                        }


                        if (strReplaceText != "")
                            rngDoc.Find.Execute(Replace: replaceOne);


                        rngDoc.Move();

                        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);

                    } while (rngDoc.Find.Found);

                    return true;
                }
            }


            return false;

        }

        public static Microsoft.Office.Interop.Word.Document LoadWordDocument(string strDoc)
        {
            object oMissing = System.Reflection.Missing.Value;
            wordApp = new Microsoft.Office.Interop.Word.Application();

            try
            {
                wordApp.Visible = false;
                wordApp.ScreenUpdating = false;

                Object filename = (Object)strDoc;
                Microsoft.Office.Interop.Word.Document mdoc = wordApp.Documents.Open(ref filename, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                return mdoc;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static List<string> DocumentRegEx(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx, RegexOptions.Multiline);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            //MatchCollection m = regexText.Matches(strDocContent);

            while (m.Success)
            {
                if (strMatchText.Contains(m.Value) == false)
                    strMatchText.Add(m.Value);
                m = m.NextMatch();
            }

            return strMatchText;
        }
        public static List<string> SortStringListOnLength(List<string> strStringColl)
        {
            List<string> strTmp = new List<string>();
            int nIndex = 0;
            int nCounter = 0;

            string strMid = null;

            strTmp = strStringColl;

            for (nIndex = 0; nIndex < strStringColl.Count; nIndex++)
            {
                for (nCounter = nIndex + 1; nCounter < strTmp.Count; nCounter++)
                {
                    if (strStringColl[nIndex].Length < strTmp[nCounter].Length)
                    {
                        strMid = strStringColl[nIndex];
                        strStringColl[nIndex] = strTmp[nCounter];
                        strTmp[nCounter] = strMid;
                        strMid = "";
                    }
                }
            }

            return strStringColl;
        }
        public static void Replaceplaceholders(string wordFilePath)
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        r.Find.Execute(" ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("  ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("et al.", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "et al.", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" et al,", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " et al,", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" et al:", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " et al:", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" et al;", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " et al;", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        //r.Find.Execute(" et al", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " et al", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        //r.Find.Execute(" et al ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " et al ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }



    }
}
