﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using System.IO;
using System.Text.RegularExpressions;
using A = DocumentFormat.OpenXml.Drawing;
using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
using PIC = DocumentFormat.OpenXml.Drawing.Pictures;
using System.Diagnostics;

namespace MultiInstancePublishingHTML2Word
{
    class MapStylesWithWordTemplate
    {
        static List<string> strValidParagraphStyles;

        static List<string> strValidCharacterStyles;

        public static void MapandApplyStyles(string strDoc)
        {
            strValidParagraphStyles = new List<string>();

            strValidParagraphStyles = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.str3CMValidParagraphStyleConfig);

            strValidCharacterStyles = new List<string>();

            strValidCharacterStyles = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.str3CMValidCharacterStyleConfig);


            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(strDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = true,//Commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        if (R != null && R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value != null)
                        {
                            string runStyle = R.RunProperties.RunStyle.Val.Value;

                            foreach (var strRunStyle in strValidCharacterStyles)
                            {
                                if (strRunStyle.ToLower() == runStyle.ToLower())
                                {
                                    R.RunProperties.RunStyle.Val.Value = strRunStyle;
                                    break;
                                }
                            }
                        }
                    }

                    if (P != null && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null)
                    {
                        string paraStyle = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                        foreach (var strParaStyle in strValidParagraphStyles)
                        {
                            if (strParaStyle.ToLower() == paraStyle.ToLower())
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = strParaStyle;
                                break;
                            }
                        }
                    }
                }

                D.Save();
                WPD.Close();
            }
        }

        public static void ReplaceSpaceWithTabInListNum(string strDoc)
        {
            string strAlpha = null;
            string strNum = null;
            string strStar = null;
            string strDash = null;
            string strRoman = null;
            string strBull1 = null;
            string strBull2 = null;
            string strBull3 = null;
            string strBull4 = null;
            string strBull5 = null;
            string strBull6 = null;
            string strBull7 = null;
            string strBull8 = null;
            string strBull9 = null;
            string strBull10 = null;
            string strNumWithBracket = null;
            string strNumWithBracketDot = null;
            string strNumWithoutSpace = null;
            string strAlphaNum = null;
            string strParaText = null;
            string strQuesAns = null;


            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(strDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = true,//Commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<string> listnumParaStyles = new List<string>() { "NumList", "AlphaLowerList", "BullList", "DashList", "TableFoot", "TableFootIndent1", "TableFootIndent2", "TableFootIndent3", "TableFootIndLevel1", "Tablefootnote_f", "Tablefootnote_m" };

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && listnumParaStyles.Any(x => x == P.ParagraphProperties.ParagraphStyleId.Val.Value))
                    {
                        int runCount = P.Descendants<Run>().Count();

                        if (runCount > 0)
                        {
                            Run firstRun = P.Descendants<Run>().First();
                            strParaText = null;
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                foreach (OpenXmlElement ox in R.Elements())
                                {
                                    if (ox.XName == W.t)
                                    {
                                        strParaText += ox.InnerText;
                                    }
                                }
                            }

                            if (strParaText != null)
                            {
                                strRoman = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^\(?\[?\{?([ivxIVX]{1,})[\.\}\)\]]{1,2}\s+");
                                strAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^\(?\[?\{?([a-zA-Z]{1,2})[\.\}\)\]]{1,2}\s+");
                                strNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[0-9]{1,2}\.\s+");
                                strStar = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[*]{1,}\s+");
                                strDash = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[-]{1,}\s+");
                                strNumWithBracket = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^\(?\[?\{?[0-9]{1,2}\.?\}?\)?\]?\s+");
                                strNumWithBracketDot = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^\(?\[?\{?[0-9]{1,2}\.[0-9]{1,2}\.?\}?\)?\]?\s+");
                                strNumWithoutSpace = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[0-9]{1,2}\.?\s+");
                                strAlphaNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^\(?\[?\{?([a-zA-Z\.]{1,2})\}?\]?\)?\(?\[?\{?([0-9\.]{1,2})\}?\]?\)?\s+");
                                strBull1 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[•]{1,}\s+");
                                strBull2 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[●]{1,}\s+");
                                strBull3 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[■]{1,}\s+");
                                strBull4 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[▪]{1,}\s+");
                                strBull5 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[†]{1,}\s+");
                                strBull6 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[#]{1,}\s+");
                                strBull7 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[]{1,}\s+");
                                strBull8 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[+]{1,}\s+");
                                strBull9 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[\^]{1,}\s+");
                                strBull10 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[o]{1,}\s+");
                                strQuesAns = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^([QA]{1,})[\:]{1}\s+");

                                if (strRoman != null)
                                {
                                    if (strParaText.StartsWith(strRoman.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strRoman.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strRoman.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strRoman.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strAlpha != null)
                                {
                                    if (strParaText.StartsWith(strAlpha.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strAlpha.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strAlpha.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strAlpha.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strNumWithBracketDot != null)
                                {
                                    if (strParaText.StartsWith(strNumWithBracketDot.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strNumWithBracketDot.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strNumWithBracketDot.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strNumWithBracketDot.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strNumWithBracket != null)
                                {
                                    if (strParaText.StartsWith(strNumWithBracket.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strNumWithBracket.Trim()))
                                                    {
                                                        //Text newText = new Text(numText.Remove(0, strNumWithBracket.Trim().Length).Trim());
                                                        Text newText = new Text(numText.Remove(0, strNumWithBracket.Trim().Length));////trim() remove by vikas on 05-11-2019 for portuguese sample

                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strNumWithBracket.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }

                                else if (strNum != null)
                                {
                                    if (strParaText.StartsWith(strNum.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strNum.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strNum.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strNum.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strNumWithoutSpace != null)
                                {
                                    var prevele = P.PreviousSibling();
                                    if (prevele.XName == W.tbl)
                                    {
                                        if (strParaText.StartsWith(strNumWithoutSpace.Trim()))
                                        {
                                            Run newRun = new Run();
                                            string numText = null;
                                            bool numFound = false;
                                            foreach (Run eachRun in P.Descendants<Run>().ToList())
                                            {
                                                foreach (var ele in eachRun.Elements())
                                                {
                                                    if (ele.XName == W.t)
                                                    {
                                                        numText += ele.InnerText;

                                                        if (numText.Trim().Contains(strNumWithoutSpace.Trim()))
                                                        {
                                                            Text newText = new Text(numText.Remove(0, strNumWithoutSpace.Trim().Length).Trim());
                                                            if (eachRun.RunProperties != null)
                                                            {
                                                                newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                            }
                                                            newRun.Append(newText);
                                                            eachRun.InsertBeforeSelf(newRun);
                                                            eachRun.Remove();

                                                            numFound = true;
                                                            break;
                                                        }
                                                        else
                                                        {
                                                            eachRun.Remove();
                                                        }
                                                    }
                                                }
                                                if (numFound)
                                                {
                                                    break;
                                                }
                                            }

                                            numText = numText.Substring(0, strNumWithoutSpace.Trim().Length);

                                            Text newNumText = new Text(numText);
                                            TabChar tb = new TabChar();

                                            Run newNumRun = new Run();

                                            if (firstRun.RunProperties != null)
                                            {
                                                newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                                //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                                //}
                                                //else
                                                //{
                                                //    RunProperties rProp = new RunProperties();
                                                //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                                //    newNumRun.Append(rProp.CloneNode(true));
                                            }

                                            newNumRun.Append(newNumText);
                                            newNumRun.Append(tb);

                                            newRun.InsertBeforeSelf(newNumRun);
                                        }
                                    }
                                    goto nextPara;
                                }
                                else if (strAlphaNum != null)
                                {
                                    if (strParaText.StartsWith(strAlphaNum.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strAlphaNum.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strAlphaNum.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strAlphaNum.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strStar != null)
                                {
                                    if (strParaText.StartsWith(strStar.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strStar.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strStar.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strStar.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strQuesAns != null)
                                {
                                    if (strParaText.StartsWith(strQuesAns.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strQuesAns.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strQuesAns.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strQuesAns.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strDash != null)
                                {
                                    if (strParaText.StartsWith(strDash.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strDash.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strDash.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strDash.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull1 != null)
                                {
                                    if (strParaText.StartsWith(strBull1.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull1.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull1.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull1.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull2 != null)
                                {
                                    if (strParaText.StartsWith(strBull2.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            if (numFound == false)
                                            {
                                                foreach (var ele in eachRun.Elements())
                                                {
                                                    if (ele.XName == W.t)
                                                    {
                                                        numText += ele.InnerText;

                                                        if (numText.Trim().Contains(strBull2.Trim()))
                                                        {
                                                            Text newText = new Text(numText.Remove(0, strBull2.Trim().Length).Trim());
                                                            if (eachRun.RunProperties != null)
                                                            {
                                                                newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                            }
                                                            newRun.Append(newText);
                                                            eachRun.InsertBeforeSelf(newRun);
                                                            eachRun.Remove();

                                                            numFound = true;
                                                            break;
                                                        }
                                                        else
                                                        {
                                                            eachRun.Remove();
                                                        }
                                                    }
                                                }
                                                //if (numFound)
                                                //{
                                                //    break;
                                                //}
                                            }
                                            else
                                            {
                                                foreach (var ele in eachRun.Elements())
                                                { }
                                            }
                                        }

                                        numText = numText.Substring(0, strBull2.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull3 != null)
                                {
                                    if (strParaText.StartsWith(strBull3.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull3.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull3.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull3.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull4 != null)
                                {
                                    if (strParaText.StartsWith(strBull4.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull4.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull4.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull4.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull5 != null)
                                {
                                    if (strParaText.StartsWith(strBull5.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull5.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull5.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull5.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull6 != null)
                                {
                                    if (strParaText.StartsWith(strBull6.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull6.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull6.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull6.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull7 != null)
                                {
                                    if (strParaText.StartsWith(strBull7.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull7.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull7.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull7.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull8 != null)
                                {
                                    if (strParaText.StartsWith(strBull8.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull8.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull8.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull8.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull9 != null)
                                {
                                    if (strParaText.StartsWith(strBull9.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull9.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull9.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull9.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                                else if (strBull10 != null)
                                {
                                    if (strParaText.StartsWith(strBull10.Trim()))
                                    {
                                        Run newRun = new Run();
                                        string numText = null;
                                        bool numFound = false;
                                        foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        {
                                            foreach (var ele in eachRun.Elements())
                                            {
                                                if (ele.XName == W.t)
                                                {
                                                    numText += ele.InnerText;

                                                    if (numText.Trim().Contains(strBull10.Trim()))
                                                    {
                                                        Text newText = new Text(numText.Remove(0, strBull10.Trim().Length).Trim());
                                                        if (eachRun.RunProperties != null)
                                                        {
                                                            newRun.Append(eachRun.RunProperties.CloneNode(true));
                                                        }
                                                        newRun.Append(newText);
                                                        eachRun.InsertBeforeSelf(newRun);
                                                        eachRun.Remove();

                                                        numFound = true;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        eachRun.Remove();
                                                    }
                                                }
                                            }
                                            if (numFound)
                                            {
                                                break;
                                            }
                                        }

                                        numText = numText.Substring(0, strBull10.Trim().Length);

                                        Text newNumText = new Text(numText);
                                        TabChar tb = new TabChar();

                                        Run newNumRun = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            newNumRun.Append(firstRun.RunProperties.CloneNode(true));
                                            //    newNumRun.RunProperties.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //}
                                            //else
                                            //{
                                            //    RunProperties rProp = new RunProperties();
                                            //    rProp.RunStyle = new RunStyle() { Val = "ListNum" };
                                            //    newNumRun.Append(rProp.CloneNode(true));
                                        }

                                        newNumRun.Append(newNumText);
                                        newNumRun.Append(tb);

                                        newRun.InsertBeforeSelf(newNumRun);
                                    }

                                    goto nextPara;
                                }
                            }
                        }
                    }
                    nextPara:
                    {
                        strAlpha = null;
                        strNum = null;
                        strStar = null;
                        strDash = null;
                        strRoman = null;
                        strBull1 = null;
                        strBull2 = null;
                        strBull3 = null;
                        strBull4 = null;
                        strBull5 = null;
                        strBull6 = null;
                        strBull7 = null;
                        strBull8 = null;
                        strBull9 = null;
                        strBull10 = null;
                        strParaText = null;
                    }
                }
                D.Save();
                WPD.Close();
            }
        }

        public static void Abtxt_StyleApplied(string newDoc)////added by narayan on 12-04-2019
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool abfound = false;
                bool nextH1 = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "AB")
                            {
                                abfound = true;
                                nextH1 = false;
                                continue;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1")
                            {
                                if (P.InnerText.ToLower().StartsWith("keywords"))
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "KYWD";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "KYWD" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" });
                                    }
                                }
                                nextH1 = true;
                                abfound = false;
                                break;
                            }
                        }
                    }
                    if (abfound)
                    {
                        if (P != null && P.InnerText != null)
                        {
                            if (P.InnerText.Length > 100)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {

                                        if (P.ParagraphProperties.Indentation == null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "AB-TXT";
                                            P.ParagraphProperties.Indentation = new Indentation { FirstLine = "36 pt" };
                                        }
                                        else
                                        {
                                            if (P.ParagraphProperties.Indentation != null)
                                            {
                                                if (P.ParagraphProperties.Indentation.FirstLine != null)
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId.Val = "AB-TXT";
                                                }
                                            }
                                        }

                                    }
                                    else
                                    {
                                        ParagraphProperties Pp;
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AB-TXT" };
                                        Indentation i = P.ParagraphProperties.Indentation;

                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AB-TXT" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void RemoveSpaceFromCellWithOnlySpace(string strProcessDocument)
        {
            using (DocumentFormat.OpenXml.Packaging.WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(strProcessDocument, true))
            {
                OpenXmlPowerTools.SimplifyMarkupSettings settings = new OpenXmlPowerTools.SimplifyMarkupSettings
                {
                    //RemoveComments = false,//Commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                var all = D.MainDocumentPart.Document.Body.Elements<DocumentFormat.OpenXml.Wordprocessing.Table>();

                if (all == null)
                    return;

                foreach (var tb in all.ToList())
                {
                    List<DocumentFormat.OpenXml.Wordprocessing.TableRow> rowitems = tb.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList();

                    for (int nCounter = 0; nCounter < rowitems.Count; nCounter++)
                    {
                        List<DocumentFormat.OpenXml.Wordprocessing.TableCell> cellitems = rowitems[nCounter].Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList();

                        for (int nIndex = 0; nIndex < cellitems.Count; nIndex++)
                        {
                            List<DocumentFormat.OpenXml.Wordprocessing.Paragraph> para = cellitems[nIndex].Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList();

                            for (int nPIndex = 0; nPIndex < para.Count; nPIndex++)
                            {
                                List<DocumentFormat.OpenXml.Wordprocessing.Run> Prun = para[nPIndex].Descendants<DocumentFormat.OpenXml.Wordprocessing.Run>().ToList();

                                for (int nRIndex = 0; nRIndex < Prun.Count; nRIndex++)
                                {
                                    List<DocumentFormat.OpenXml.Wordprocessing.Text> Rtext = Prun[nRIndex].Descendants<DocumentFormat.OpenXml.Wordprocessing.Text>().ToList();

                                    string strText = "";
                                    Text TT = null;
                                    for (int nTIndex = 0; nTIndex < Rtext.Count; nTIndex++)
                                    {
                                        TT = Rtext[nTIndex];
                                        strText += Rtext[nTIndex].Text;
                                    }

                                    if (TT != null)
                                    {
                                        //if (strText != null && strText != "")
                                        //{
                                        //if (strText == " " || strText == " ")
                                        //{
                                        //    TT.Remove();
                                        //}
                                        //}

                                        if (TT.InnerText.Trim() == null || TT.InnerText.Trim() == "")
                                        {
                                            bool remove = true;
                                            foreach (var attr in TT.GetAttributes().ToList())
                                            {
                                                if (attr.XName.LocalName.ToLower() == "space")
                                                {
                                                    remove = false;
                                                }
                                            }

                                            if (remove)
                                            {
                                                TT.Remove();
                                            }

                                            //Prun[nRIndex].Append(new Text(" ") { Space = SpaceProcessingModeValues.Preserve }); //Added by Manish on 19-06-2018
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
                WPD.Close();
            }
        }

        public static void UpdateTableCellWidth(string strProcessDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                var allTables = D.Body.Elements<DocumentFormat.OpenXml.Wordprocessing.Table>();

                foreach (var tb in allTables)
                {
                    if (tb.HasChildren)
                    {
                        List<DocumentFormat.OpenXml.Wordprocessing.TableRow> rowitems = tb.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList();

                        for (int nCounter = 0; nCounter < rowitems.Count; nCounter++)
                        {
                            List<DocumentFormat.OpenXml.Wordprocessing.TableCell> cellitems = rowitems[nCounter].Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList();

                            for (int nIndex = 0; nIndex < cellitems.Count; nIndex++)
                            {
                                if (cellitems[nIndex].TableCellProperties != null)
                                {
                                    if (cellitems[nIndex].TableCellProperties.TableCellWidth != null)
                                    {
                                        if (cellitems[nIndex].TableCellProperties.TableCellWidth.GetAttributes().Count > 0)
                                        {
                                            string strCellWidth = null;
                                            if (cellitems[nIndex].TableCellProperties.TableCellWidth.Width != null)
                                            {
                                                strCellWidth = cellitems[nIndex].TableCellProperties.TableCellWidth.Width;
                                            }

                                            if (strCellWidth == null || strCellWidth == "0")
                                            {
                                                cellitems[nIndex].TableCellProperties.TableCellWidth.Width = "50";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
                WPD.Close();
            }
        }

        public static string UnixTimeStampToDateTime(double unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddMilliseconds(unixTimeStamp).ToLocalTime();
            return dtDateTime.ToString("yyyy-MM-dd hh:mm");
        }

        public static void ChangeAllInsertDeleteSpan(string strDocument)
        {
            HtmlDocument doc = new HtmlDocument();
            doc.Load(strDocument, Encoding.UTF8);

            HtmlNodeCollection insNodes = doc.DocumentNode.SelectNodes("//ins");

            if (insNodes != null)
            {
                foreach (HtmlNode ins in insNodes.ToList())
                {
                    string revid = null;
                    string author = null;
                    string datetime = null;
                    string cite = null;

                    if (ins.HasAttributes)
                    {
                        foreach (var attr in ins.Attributes)
                        {
                            if (attr.Name == "data-username")
                            {
                                author = attr.Value;
                            }
                            if (attr.Name == "data-revision")
                            {
                                revid = attr.Value;
                            }
                            if (attr.Name == "data-time")
                            {
                                double dttime = Convert.ToDouble(attr.Value);

                                datetime = UnixTimeStampToDateTime(dttime);
                            }
                        }
                    }

                    if (revid == null)
                    {
                        cite = author;
                    }
                    else if (revid != null && author != null)
                    {
                        cite = revid + "Rmailto:" + author;
                    }

                    if (cite != null)
                    {
                        ins.SetAttributeValue("cite", cite);
                    }
                    if (datetime != null)
                    {
                        ins.SetAttributeValue("datetime", datetime.Replace(" ", "T"));
                    }
                }
            }


            HtmlNodeCollection delNodes = doc.DocumentNode.SelectNodes("//del");

            if (delNodes != null)
            {
                foreach (HtmlNode del in delNodes.ToList())
                {
                    string revid = null;
                    string author = null;
                    string datetime = null;

                    if (del.HasAttributes)
                    {
                        foreach (var attr in del.Attributes)
                        {
                            if (attr.Name == "data-username")
                            {
                                author = attr.Value;
                            }
                            if (attr.Name == "data-revision")
                            {
                                revid = attr.Value;
                            }
                            if (attr.Name == "data-time")
                            {
                                double dttime = Convert.ToDouble(attr.Value);

                                datetime = UnixTimeStampToDateTime(dttime);
                            }
                        }
                    }

                    if (revid != null && author != null)
                    {
                        del.SetAttributeValue("cite", revid + "Rmailto:" + author);
                    }
                    if (datetime != null)
                    {
                        del.SetAttributeValue("datetime", datetime.Replace(" ", "T"));
                    }
                }
            }

            doc.Save(strDocument, Encoding.UTF8);

        }

        public static void ReadWordHTMLTemplateAndStoreInHead(string strDocument, string styletag)
        {
            FileStream inFile = new FileStream(styletag, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            HtmlDocument doc = new HtmlDocument();
            doc.Load(strDocument, Encoding.UTF8);

            //HtmlNode Style = doc.CreateElement(reader.ReadToEnd());

            HtmlNode Style = HtmlNode.CreateNode(reader.ReadToEnd());

            HtmlNode header = doc.DocumentNode.SelectSingleNode("//head");

            HtmlNode existingstyle = header.Descendants("style").FirstOrDefault();

            if (existingstyle != null)
            {
                existingstyle.Remove();
            }

            header.AppendChild(Style);
            doc.Save(strDocument, Encoding.UTF8);
        }
        public static void ReadWordHTMLStyle(string strDocument)
        {

            HtmlDocument doc = new HtmlDocument();
            doc.Load(strDocument, Encoding.UTF8);

            var value = "";

            doc.DocumentNode.Descendants("p").ToList().ForEach(x =>
            {
                if (x.GetAttributeValue("style", "").Replace(" ", "").Contains("mso-style-name") && x.GetAttributeValue("class", "") != "")
                {
                    x.GetAttributeValue("style", "").Split(';').ToList().ForEach(y =>
                    {
                        if (y.Replace(" ", "").StartsWith("mso-style-name:"))
                        {

                            value = y.Split(':')[1];
                        }

                    });
                    x.SetAttributeValue("style", x.GetAttributeValue("style", "").Replace(value, x.GetAttributeValue("class", "")));

                }

            });

            doc.Save(strDocument, Encoding.UTF8);
        }
        public static void RemoveTextFromStartOrEndStyles(string strDocument)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(strDocument, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null
                        && (P.ParagraphProperties.ParagraphStyleId.Val.Value.EndsWith("Start") || P.ParagraphProperties.ParagraphStyleId.Val.Value.EndsWith("End")))
                    {
                        if (P.InnerText != null)
                        {
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                if (R != null)
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (T.Text.Trim() == "")
                                        {
                                            T.Text = "";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void CheckForEquation(string strDocument)
        {
            bool mathmlAdd = false;
            HtmlDocument doc = new HtmlDocument();
            doc.Load(strDocument, Encoding.UTF8);
            FileInfo fInfo = new FileInfo(strDocument);
            string eqDirPath = fInfo.DirectoryName + "\\Equations";
            if (Directory.Exists(eqDirPath) == false)
                Directory.CreateDirectory(eqDirPath);
            var spanNodes = doc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "IEQ").ToList();  //Developer Name:Priyanka Vishwakarma,Date:29-07-2021,Requirement:Add condition for handling equation on basis of span with class "IEQ".
            foreach (HtmlNode spanNode in spanNodes.ToList())
            {
                mathmlAdd = false;
                string strFormID = null;
                foreach (HtmlAttribute srcattr in spanNode.Attributes.ToList())
                {
                    if (srcattr.Name == "class" && srcattr.Value == "IEQ")
                    {
                        string strLatex = null;

                        ///////////////////////////////
                        for (int i = 0; i < spanNode.Attributes.Count; i++)
                        {
                            if (spanNode.Attributes[i].Name == "data-latex")
                            {
                                strLatex = spanNode.Attributes[i].Value;
                            }
                            if (spanNode.Attributes[i].Name == "formula-id")
                            {
                                strFormID = spanNode.Attributes[i].Value;
                            }
                        }

                        if (strLatex != null && strFormID != null)
                        {
                            using (StreamWriter writer = new StreamWriter(eqDirPath + "\\" + strFormID + "_TeX.txt"))
                            {
                                writer.Write("<math>" + strLatex + "</math>");
                                writer.Close();
                            }
                        }
                        //////////////////////////////////////
                        //only if condition added by Karan on 09-10-2018 Start= if (strLatex != null && strFormID != null)
                        if (spanNode.Descendants("math").ToList().Count() == 1 && mathmlAdd == false)
                        {
                            var mathMLNode = spanNode.Descendants("math").ToList().FirstOrDefault();
                            var strMathml = "";
                            strMathml = mathMLNode.OuterHtml;

                            if (mathMLNode != null)
                            {
                                using (StreamWriter writer = new StreamWriter(eqDirPath + "\\" + strFormID + "_MathMl.txt"))
                                {
                                    writer.Write("<!-- MathType@Translator@5@5@MathML2 (m namespace).tdl@MathML 2.0 (m namespace)@ -->");
                                    writer.Write("\n");
                                    writer.Write(strMathml);
                                    writer.Close();
                                }
                            }
                            mathmlAdd = true;

                        }
                        if (strFormID != null)
                        {
                            HtmlNode newtext = HtmlNode.CreateNode(spanNode.GetAttributeValue("formula-id", ""));

                            if (spanNode.ChildNodes.Count > 0)
                            {
                                spanNode.ChildNodes.ToList().ForEach(x => x.Remove());
                            }
                            spanNode.AppendChild(newtext);
                        }

                    }
                }

            }

            doc.Save(strDocument, Encoding.UTF8);
        }


        //public static void CheckForEquation(string strDocument)
        //{
        //    HtmlDocument doc = new HtmlDocument();
        //    doc.Load(strDocument, Encoding.UTF8);

        //    HtmlNodeCollection paraNodes = doc.DocumentNode.SelectNodes("//p");

        //    HtmlNodeCollection imgNodes = doc.DocumentNode.SelectNodes("//img");

        //    bool equationFound = false;

        //    if (imgNodes != null)
        //    {
        //        FileInfo fInfo = new FileInfo(strDocument);

        //        string eqDirPath = fInfo.DirectoryName + "\\Equations";

        //        if (Directory.Exists(eqDirPath) == false)
        //            Directory.CreateDirectory(eqDirPath);


        //        foreach (HtmlNode img in imgNodes.ToList())
        //        {
        //            equationFound = false;
        //            foreach (HtmlAttribute srcattr in img.Attributes.ToList())
        //            {
        //                if (srcattr.Name == "class" && srcattr.Value == "Wirisformula")
        //                {

        //                    equationFound = true;

        //                    string strLatex = null;
        //                    string strFormID = null;

        //                    for (int i = 0; i < img.ParentNode.Attributes.Count; i++)
        //                    {
        //                        if (img.ParentNode.Attributes[i].Name == "data-latex")
        //                        {
        //                            strLatex = img.ParentNode.Attributes[i].Value;
        //                        }
        //                        if (img.ParentNode.Attributes[i].Name == "formula-id")
        //                        {
        //                            strFormID = img.ParentNode.Attributes[i].Value;
        //                        }
        //                    }

        //                    if (strLatex != null && strFormID != null)
        //                    {
        //                        using (StreamWriter writer = new StreamWriter(eqDirPath + "\\" + strFormID + "_TeX.txt"))
        //                        {
        //                            writer.Write("<math>" + strLatex + "</math>");
        //                            writer.Close();
        //                        }
        //                    }

        //                   // only if condition added by Karan on 09 - 10 - 2018 Start = if (strLatex != null && strFormID != null)
        //                        //if (strFormID != null)
        //                        //{
        //                        //    HtmlNode newtext = HtmlNode.CreateNode(strFormID);

        //                        //    img.ParentNode.ReplaceChild(newtext, img);




        //                        //    para.RemoveAllChildren();

        //                        //    HtmlNode newpara = HtmlNode.CreateNode("<p class=EQ>" + strFormID + "</p>");

        //                        //    para.ParentNode.ReplaceChild(newpara, para);
        //                        //    para.Remove();
        //                        //}
        //              //      if condition added by Karan on 09 - 10 - 2018 Start
        //                }
        //                if (equationFound)
        //                {
        //                    break;
        //                }
        //            }
        //        }
        //    }

        //    /////Added by vikas on 26-03-2021 for epub content and journal skip RFA,RPE stage if not selected copyeiting
        //    if (equationFound == false)
        //    {
        //        var spanNodes = doc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "IEQ").ToList();
        //        foreach (HtmlNode span in spanNodes.ToList())
        //        {
        //            if (span.GetAttributeValue("formula-id", "") != "")
        //            {

        //                HtmlNode newtext = HtmlNode.CreateNode(span.GetAttributeValue("formula-id", ""));

        //                if (span.ChildNodes.Count > 0)
        //                {
        //                    span.ChildNodes.ToList().ForEach(x => x.Remove());
        //                }
        //                span.AppendChild(newtext);
        //            }
        //        }
        //    }

        //    if (paraNodes != null)
        //    {
        //        foreach (HtmlNode para in paraNodes.ToList())
        //        {
        //            equationFound = false;
        //            foreach (var attr in para.Attributes.ToList())
        //            {
        //                if (attr.Name == "class" && attr.Value == "EQ")
        //                {
        //                    FileInfo fInfo = new FileInfo(strDocument);

        //                    string eqDirPath = fInfo.DirectoryName + "\\Equations";

        //                    if (Directory.Exists(eqDirPath) == false)
        //                        Directory.CreateDirectory(eqDirPath);

        //                    equationFound = true;

        //                    string strLatex = null;
        //                    string strFormID = null;

        //                    for (int i = 0; i < para.Attributes.Count; i++)
        //                    {
        //                        if (para.Attributes[i].Name == "data-latex")
        //                        {
        //                            strLatex = para.Attributes[i].Value;
        //                        }
        //                        if (para.Attributes[i].Name == "formula-id")
        //                        {
        //                            strFormID = para.Attributes[i].Value;
        //                        }
        //                    }

        //                    if (strLatex != null && strFormID != null)
        //                    {
        //                        using (StreamWriter writer = new StreamWriter(eqDirPath + "\\" + strFormID + "_TeX.txt"))
        //                        {
        //                            writer.Write("<math>" + strLatex + "</math>");
        //                            writer.Close();
        //                        }
        //                    }

        //                    //only if condition added by Karan on 09-10-2018 Start= if (strLatex != null && strFormID != null)
        //                    if (strLatex != null && strFormID != null)
        //                    {
        //                        para.RemoveAllChildren();

        //                        HtmlNode newpara = HtmlNode.CreateNode("<p class=EQ>" + strFormID + "</p>");

        //                        para.ParentNode.ReplaceChild(newpara, para);
        //                        para.Remove();
        //                    }
        //                    //if condition added by Karan on 09-10-2018 Start 
        //                }
        //                if (equationFound)
        //                {
        //                    break;
        //                }
        //            }
        //        }
        //    }
        //    doc.Save(strDocument, Encoding.UTF8);
        //}
        ////Developer Name:Priyanka Vishwakarma ,Date:13_08_2019, Requirement: Table converted into text because of comments, Integrated by:Vikas sir.
        public static void ReadCommentFromHtmlAndRemove(string strDocument)
        {

            HtmlDocument newdoc = new HtmlDocument();

            newdoc.Load(strDocument, Encoding.UTF8);



            newdoc.DocumentNode.Descendants().ToList().Where(n => n.NodeType == HtmlAgilityPack.HtmlNodeType.Comment).ToList()
    .ForEach(n =>
    {
        if (n.InnerHtml.Contains("!supportMisalignedRows"))
        {
            n.Remove();
        }
    });

            newdoc.Save(strDocument, Encoding.UTF8);
            //HtmlDocument doc = new HtmlDocument();
            //doc.Load(strDocument, Encoding.UTF8);

            //foreach (HtmlNode a in doc.DocumentNode.Descendants().ToList().Where(x => x.NodeType.ToString() == "Comment"))
            //{
            //    a.Remove();
            //}
            //doc.Save(strDocument, Encoding.UTF8);
        }
        //Developer name:Priyanka Vishwakarma ,Date:23_09_2019 ,Requirement:Remove Author Query heading ,Integrated by:Vikas sir.
        public static void removeAuthorQueryHeading(string strDocument)
        {
            HtmlDocument doc = new HtmlDocument();
            doc.Load(strDocument, Encoding.UTF8);

            foreach (HtmlNode p in doc.DocumentNode.Descendants().ToList().Where(x => x.Name == "p" && x.InnerText.ToLower() == "author queries").ToList())
            {
                p.Remove();
                break;
            }
            doc.Save(strDocument, Encoding.UTF8);
        }

        //change on 07-01-2020 
        public static void ReadCommentTextBeforeConvet(string strDocument)   //07_01_2020
        {

            HtmlDocument newdoc = new HtmlDocument();

            newdoc.Load(strDocument, Encoding.UTF8);
            List<string> List1 = new List<string>();
            string cmttext = null;
            string replaceTextWithiinPara = null;
            //foreach (var text in newdoc.DocumentNode.Descendants("p").ToList())
            //{
            //    if (text.GetAttributeValue("class", "").Replace(" ", "").Contains("MsoCommentText") && text.GetAttributeValue("class", "") != "")  //02-03-2020
            //    {
            foreach (var text in newdoc.DocumentNode.Descendants("div").ToList())    //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
            {
                if (text.GetAttributeValue("class", "").Replace(" ", "").Contains("msocomtxt") && text.GetAttributeValue("class", "") != "")
                {
                    cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim();

                    if (text.InnerText.ToLower().Trim().Contains("queries are missing:"))
                    {
                        cmttext = text.InnerText.Trim().ToString().Substring(text.InnerText.Trim().ToString().LastIndexOf("]") + 1).Replace("&quot;", "\"");
                    }
                    else if (text.InnerText.ToLower().Trim().Contains("au:"))
                    {
                        cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim();   //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
                        string replaceText = GlobalMethods.RegExSearch(cmttext, @"^([AU:|au:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,})|^([AU:|au:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]])|^([\[][a-zA-Z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]][AU:|au:]+)|^([\[][a-zA-Z0-9]+\][AU:|au:]+\s{0,}[\[][a-zA-Z0-9]+[\]])|^([\[][A-Za-z]+\-[\[][0-9]+[\]][AU:|au:]+)|^([\[][a-zA-Z0-9]+\][AU:|au:]+)");
                        if (replaceText != "")
                        {

                            if (!string.IsNullOrEmpty(replaceText) && cmttext.Contains(replaceText))
                            {
                                cmttext = cmttext.Replace(replaceText, "AU: ").Trim().Replace("&quot;", "\"");
                            }

                            replaceTextWithiinPara = replaceText.Replace("AU:", "").Replace("au:", "");

                            if (cmttext.Contains(" " + replaceTextWithiinPara))
                            {
                                cmttext = cmttext.Replace(" " + replaceTextWithiinPara, "");
                            }
                            else
                            {
                                cmttext = cmttext.Replace(replaceTextWithiinPara, "");
                            }

                        }

                    }

                    else if (text.InnerText.ToLower().Trim().Contains("pm"))
                    {
                        cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim();  //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
                        string replaceText = GlobalMethods.RegExSearch(cmttext, @"^([PM:|pm:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,})|^([PM:|pm:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]])|^([\[][a-zA-Z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]][PM:|pm:]+)|^([\[][a-zA-Z0-9]+\][PM:|pm:]+\s{0,}[\[][a-zA-Z0-9]+[\]])|^([\[][A-Za-z]+\-[\[][0-9]+[\]][PM:|pm:]+)|^([\[][a-zA-Z0-9]+\][PM:|pm:]+)");

                        if (replaceText != "")
                        {
                            if (!string.IsNullOrEmpty(replaceText) && cmttext.Contains(replaceText))
                            {
                                cmttext = cmttext.Replace(replaceText, "PM: ").Trim().Replace("&quot;", "\"");
                            }

                            replaceTextWithiinPara = replaceText.Replace("PM:", "").Replace("pm:", "");

                            if (cmttext.Contains(" " + replaceTextWithiinPara))
                            {
                                cmttext = cmttext.Replace(" " + replaceTextWithiinPara, "");
                            }
                            else
                            {
                                cmttext = cmttext.Replace(replaceTextWithiinPara, "");
                            }

                        }

                    }
                    else if (text.InnerText.ToLower().Trim().Contains("ce:"))
                    {
                        cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim(); //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
                        string replaceText = GlobalMethods.RegExSearch(cmttext, @"^([CE:|ce:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,})|^([CE:|ce:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]])|^([\[][a-zA-Z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]][CE:|ce:]+)|^([\[][a-zA-Z0-9]+\][CE:|ce:]+\s{0,}[\[][a-zA-Z0-9]+[\]])|^([\[][A-Za-z]+\-[\[][0-9]+[\]][CE:|ce:]+)|^([\[][a-zA-Z0-9]+\][CE:|ce:]+)");

                        if (replaceText != "")
                        {
                            if (!string.IsNullOrEmpty(replaceText) && cmttext.Contains(replaceText))
                            {
                                cmttext = cmttext.Replace(replaceText, "CE: ").Trim().Replace("&quot;", "\"");
                            }

                            replaceTextWithiinPara = replaceText.Replace("CE:", "").Replace("ce:", "");

                            if (cmttext.Contains(" " + replaceTextWithiinPara))
                            {
                                cmttext = cmttext.Replace(" " + replaceTextWithiinPara, "");
                            }
                            else
                            {
                                cmttext = cmttext.Replace(replaceTextWithiinPara, "");
                            }
                        }


                    }
                    else if (text.InnerText.ToLower().Trim().Contains("comp:"))
                    {
                        cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim(); //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
                        string replaceText = GlobalMethods.RegExSearch(cmttext, @"^([COMP:|comp:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,})|^([COMP:|comp:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]])|^([\[][a-zA-Z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]][COMP:|comp:]+)|^([\[][a-zA-Z0-9]+\][COMP:|comp:]+\s{0,}[\[][a-zA-Z0-9]+[\]])|^([\[][A-Za-z]+\-[\[][0-9]+[\]][COMP:|comp:]+)|^([\[][a-zA-Z0-9]+\][COMP:|comp:]+)");

                        if (!string.IsNullOrEmpty(replaceText))
                        {

                            if (cmttext.Contains(replaceText))
                            {
                                cmttext = cmttext.Replace(replaceText, "COMP: ").Trim().Replace("&quot;", "\"");
                            }

                            replaceTextWithiinPara = replaceText.Replace("COMP:", "").Replace("comp:", "");

                            if (cmttext.Contains(" " + replaceTextWithiinPara))
                            {
                                cmttext = cmttext.Replace(" " + replaceTextWithiinPara, "");
                            }
                            else
                            {
                                cmttext = cmttext.Replace(replaceTextWithiinPara, "");
                            }
                        }


                    }

                    else if (text.InnerText.ToLower().Trim().Contains("comps:"))
                    {
                        cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim(); //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
                        string replaceText = GlobalMethods.RegExSearch(cmttext, @"^([COMPS:|comps:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,})|^([COMPS:|comps:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]])|^([\[][a-zA-Z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]][COMPS:|comps:]+)|^([\[][a-zA-Z0-9]+\][COMPS:|comps:]+\s{0,}[\[][a-zA-Z0-9]+[\]])|^([\[][A-Za-z]+\-[\[][0-9]+[\]][COMPS:|comps:]+)|^([\[][a-zA-Z0-9]+\][COMPS:|comps:]+)");
                        if (!string.IsNullOrEmpty(replaceText))
                        {
                            if (cmttext.Contains(replaceText))
                            {
                                cmttext = cmttext.Replace(replaceText, "COMPS: ").Trim().Replace("&quot;", "\"");
                            }

                            replaceTextWithiinPara = replaceText.Replace("COMPS:", "").Replace("comps:", "");

                            if (cmttext.Contains(" " + replaceTextWithiinPara))
                            {
                                cmttext = cmttext.Replace(" " + replaceTextWithiinPara, "");
                            }
                            else
                            {
                                cmttext = cmttext.Replace(replaceTextWithiinPara, "");
                            }

                        }

                    }
                    else if (text.InnerText.ToLower().Trim().Contains("type:"))
                    {
                        cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim(); //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
                        string replaceText = GlobalMethods.RegExSearch(cmttext, @"^([TYPE:|type:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,})|^([TYPE:|type:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]])|^([\[][a-zA-Z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]][TYPE:|type:]+)|^([\[][a-zA-Z0-9]+\][TYPE:|type:]+\s{0,}[\[][a-zA-Z0-9]+[\]])|^([\[][A-Za-z]+\-[\[][0-9]+[\]][TYPE:|type:]+)|^([\[][a-zA-Z0-9]+\][TYPE:|type:]+)");
                        if (!string.IsNullOrEmpty(replaceText))
                        {

                            if (cmttext.Contains(replaceText))
                            {
                                cmttext = cmttext.Replace(replaceText, "TYPE: ").Trim().Replace("&quot;", "\"");
                            }

                            replaceTextWithiinPara = replaceText.Replace("TYPE:", "").Replace("type:", "");

                            if (cmttext.Contains(" " + replaceTextWithiinPara))
                            {
                                cmttext = cmttext.Replace(" " + replaceTextWithiinPara, "");
                            }
                            else
                            {
                                cmttext = cmttext.Replace(replaceTextWithiinPara, "");
                            }
                        }


                    }
                    else if (text.InnerText.ToLower().Trim().Contains("typesetter:"))
                    {
                        cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim(); //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
                        string replaceText = GlobalMethods.RegExSearch(cmttext, @"^([TYPESETTER:|typesetter:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,})|^([TYPESETTER:|typesetter:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]])|^([\[][a-zA-Z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]][TYPESETTER:|typesetter:]+)|^([\[][a-zA-Z0-9]+\][TYPESETTER:|typesetter:]+\s{0,}[\[][a-zA-Z0-9]+[\]])|^([\[][A-Za-z]+\-[\[][0-9]+[\]][TYPESETTER:|typesetter:]+)|^([\[][a-zA-Z0-9]+\][TYPESETTER:|typesetter:]+)");

                        if (!string.IsNullOrEmpty(replaceText))
                        {
                            if (cmttext.Contains(replaceText))
                            {
                                cmttext = cmttext.Replace(replaceText, "TYPESETTER: ").Trim().Replace("&quot;", "\"");
                            }

                            replaceTextWithiinPara = replaceText.Replace("TYPESETTER:", "").Replace("typesetter:", "");

                            if (cmttext.Contains(" " + replaceTextWithiinPara))
                            {
                                cmttext = cmttext.Replace(" " + replaceTextWithiinPara, "");
                            }
                            else
                            {
                                cmttext = cmttext.Replace(replaceTextWithiinPara, "");
                            }
                        }

                    }
                    else if (text.InnerText.ToLower().Trim().Contains("ed:"))
                    {
                        cmttext = text.InnerText.Replace("&nbsp;", " ").Replace("\n", "").Trim(); //Developer name: Priyanka Vishwakarma ,Date:04-03-2020 Requirement:Handle Author query with Enter .Integrated by:Vikas sir
                        string replaceText = GlobalMethods.RegExSearch(cmttext, @"^([ED:|ed:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,})|^([ED:|ed:]+\s{0,}[\[][A-Za-z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]])|^([\[][a-zA-Z0-9]+[\]]\s{0,}[\[][A-Za-z0-9]+[\]][ED:|ed:]+)|^([\[][a-zA-Z0-9]+\][ED:|ed:]+\s{0,}[\[][a-zA-Z0-9]+[\]])|^([\[][A-Za-z]+\-[\[][0-9]+[\]][ED:|ed:]+)|^([\[][a-zA-Z0-9]+\][ED:|ed:]+)");
                        if (!string.IsNullOrEmpty(replaceText))
                        {

                            if (cmttext.Contains(replaceText))
                            {
                                cmttext = cmttext.Replace(replaceText, "ED: ").Trim().Replace("&quot;", "\"");
                            }

                            replaceTextWithiinPara = replaceText.Replace("ED:", "").Replace("ed:", "");

                            if (cmttext.Contains(" " + replaceTextWithiinPara))
                            {
                                cmttext = cmttext.Replace(" " + replaceTextWithiinPara, "");
                            }
                            else
                            {
                                cmttext = cmttext.Replace(replaceTextWithiinPara, "");
                            }
                        }
                    }
                    else
                    {
                        cmttext = text.InnerText.Trim().ToString().Substring(text.InnerText.Trim().ToString().LastIndexOf("]") + 1).Replace("&quot;", "\"");
                    }
                    cmttext = Regex.Replace(cmttext, @"[:]\s{1,}", ":");



                    if (cmttext != "&nbsp;")
                        GlobalMethods.beforecmt.Add(cmttext.Trim().Replace("&quot;", "\"").Replace("&nbsp;", " ").Replace(" ", " ").ToString().Trim());  //04-01-2019
                }


            }

            newdoc.Save(strDocument, Encoding.UTF8);

        }

        public static void GetCommentsAfterDocument(string fileName)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
    .Open(fileName, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                WordprocessingCommentsPart commentsPart =
                    D.MainDocumentPart.WordprocessingCommentsPart;

                if (commentsPart != null && commentsPart.Comments != null)
                {
                    foreach (Comment comment in commentsPart.Comments.Elements<Comment>())
                    {
                        string cmtText = comment.InnerText.Replace(@"PAGE \# ""'Page: '#''""", "").Trim();
                        cmtText = Regex.Replace(cmtText, @"[:]\s{1,}", ":");



                        if (cmtText.Replace(" ", "") != "")
                        {
                            cmtText = cmtText.Replace(" ", " ").Replace(" ", " ");  //04012020    replace space.
                            GlobalMethods.Aftercmt.Add(cmtText.Replace("Comp:", "COMP:").Replace("comp:", "COMP:").Replace("au:", "AU:").Replace("Au:", "AU:").Replace("Pm:", "PM:").Replace("pm:", "PM:").Replace("ce:", "CE:").Replace("Ce:", "CE:").Replace("Comps:", "COMPS:").Replace("comps:", "COMPS:").Replace("Type:", "TYPE:").Replace("type:", "TYPE:").Replace("Typesetter:", "TYPESETTER:").Replace("typesetter:", "TYPESETTER:").Replace("Ed:", "ED:").Replace("ed:", "ED:")); //COMPS  TYPE  TYPESETTER ED
                        }
                    }
                }

                D.Save();
            }

        }


        public static void checkMissingComment(string fileName, List<string> list1, List<string> list2)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(fileName, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                WordprocessingCommentsPart commentsPart =
                    D.MainDocumentPart.WordprocessingCommentsPart;


                if (list1.Count() == list2.Count())  //Developer name:Priyanka Vishwakarma ,Date:18-02-2020 ,Requirement:Author Query Abbriaviation not match with AuthorQuery because of small and caps letter. ,Integrated by:Vikas sir. 
                {
                    goto skip;
                }


                foreach (var cmt in list2.ToList())
                {
                    //list1.ForEach(y => {
                    //    if(y.ToLower()==cmt.ToLower())
                    //    {
                    //        //list1.Remove(cmt);
                    //    }
                    //});



                    if (list1.Any(x => x.ToLower().Replace(" ", "").Replace(" ", "").Contains(cmt.ToLower().Replace(" ", "").Replace(" ", ""))))
                    {
                        list1.Remove(cmt);

                    }
                }

                if (list1.Count > 0)
                {
                    string commenttxt = "Queries are Missing::";
                    foreach (var a in list1.ToList())
                    {
                        commenttxt += " " + a + " ";  //04-01-2020
                    }
                    var lastPara = D.Descendants<Paragraph>().ToList().Last();
                    int id = 0;
                    Comments comments = null;
                    if (MDP.WordprocessingCommentsPart != null && MDP.WordprocessingCommentsPart.Comments != null)
                    {
                        comments = MDP.WordprocessingCommentsPart.Comments;



                        //if(comments.InnerText.Replace(" ","").Replace(" ","").Contains(commenttxt.Replace(" ","").Replace(" ", "").Replace("QueriesareMissing::","")))
                        //{

                        //}

                        if (comments.HasChildren)
                        {
                            id = Convert.ToInt32(comments.Descendants<Comment>().ToList().LastOrDefault().Id.Value) + 1;
                        }

                        Paragraph p = new Paragraph(new Run(new Text(commenttxt)));
                        Comment cmt =
                            new Comment()
                            {
                                Id = id.ToString(),
                                Date = DateTime.Now
                            };
                        cmt.AppendChild(p);
                        comments.AppendChild(cmt);
                        comments.Save();

                        Paragraph p1 = new Paragraph();
                        Run lastcmt = (new Run(new CommentReference() { Id = id.ToString() }));
                        //Developer Name:Priyanka Vishwakarma ,Date:24-09-2020 ,Requirement:Add Author Query into new paragraph and add paragraph after last para. 
                        p1.AppendChild(lastcmt);
                        lastPara.InsertAfterSelf(p1);
                    }
                    //lastPara.AppendChild(lastcmt);
                }
                skip: { }

                D.Save();
            }
        }
        public static void Remove3CMProofingCommentimgtag(string strDocument)   //09-10-2020 by vikas for 3cm online editing author and pe comment remove before convert to word
        {

            HtmlDocument newdoc = new HtmlDocument();

            newdoc.Load(strDocument, Encoding.UTF8);

            foreach (var img in newdoc.DocumentNode.Descendants("img").Where(x => x.GetAttributeValue("data-toggle", "") != "").ToList())
            {
                if (img.ParentNode != null && img.ParentNode.Name == "span" && img.ParentNode.InnerText == "")
                {
                    img.ParentNode.Remove();
                }
            }
            newdoc.Save(strDocument, Encoding.UTF8);

        }

        public static void CheckClosingifTaginComments(string strDocument)  //Developer Name: Priyanka Vishwakarma,Date: 25-11-2021, Add function for adding comment endif in author query when endif comment missing after anchor tag
        {

            HtmlDocument newdoc = new HtmlDocument();

            newdoc.Load(strDocument, Encoding.UTF8);
            foreach (var span in newdoc.DocumentNode.Descendants("span").Where(x => x.GetAttributeValue("class", "") == "MsoCommentReference").ToList())
            {
                var commentList = span.Descendants().ToList().Where(n => n.NodeType == HtmlAgilityPack.HtmlNodeType.Comment).ToList();
                if (commentList.Count() == 1)
                {
                    if (commentList[0].InnerHtml == "<!--[if !supportAnnotations]-->")
                    {
                        var img = span.Descendants("a").Where(x => x.GetAttributeValue("class", "") == "msocomanchor").ToList().FirstOrDefault();
                        HtmlCommentNode cmt = newdoc.CreateComment("<!--[endif]-->");
                        if (img != null && img.ParentNode != null)
                            img.ParentNode.InsertAfter(cmt, img);
                    }
                    else if (commentList[0].InnerHtml == "<!--[endif]-->")
                    {
                        var img = span.Descendants("a").Where(x => x.GetAttributeValue("class", "") == "msocomanchor").ToList().FirstOrDefault();
                        HtmlCommentNode cmt = newdoc.CreateComment("<!--[if !supportAnnotations]-->");
                        if (img != null && img.ParentNode != null)
                            img.ParentNode.InsertBefore(cmt, img);
                    }
                }
            }
            newdoc.Save(strDocument, Encoding.UTF8);

        }



        ////For sage author,affilation,correspondance address
        public static void CreationofAFFLCORRandAUForSage(string htmlpath)///1725 job
        {

            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.Load(htmlpath, Encoding.UTF8);
            int cnt = 0;
            var parafirst = doc.CreateElement("#text");
            List<HtmlNode> listpara = new List<HtmlNode>();
            var AUPara = doc.CreateElement("p");
            AUPara.SetAttributeValue("class", "AU");
            AUPara.SetAttributeValue("style", "mso-layout-grid-align:none;text-autospace:none;mso-style-name:AU; mso-style-unhide:no; mso-style-parent:Base_Text; margin-top:6.0pt; margin-right:0in; margin-bottom:6.0pt; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; mso-bidi-font-size:10.0pt; font-family:'Arial','sans-serif'; mso-fareast-font-family:'Times New Roman'; mso-bidi-font-family:'Times New Roman'; font-weight:bold; mso-bidi-font-weight:normal;");

            var Affilationpara = doc.CreateElement("p");
            Affilationpara.SetAttributeValue("class", "AFFL");
            Affilationpara.SetAttributeValue("style", "mso-style-name:AFFL; mso-style-unhide:no; mso-style-parent:Base_Text; mso-style-link:'AFFL Char'; margin-top:6.0pt; margin-right:0in; margin-bottom:0in; margin-left:0in; mso-pagination:widow-orphan; font-size:10.0pt; font-family:'Times New Roman','serif'; mso-fareast-font-family:'Times New Roman';");

            var CORRpara = doc.CreateElement("p");
            CORRpara.SetAttributeValue("class", "CORR");
            CORRpara.SetAttributeValue("style", "mso-layout-grid-align:none;text-autospace:none;mso-style-name:CORR; mso-style-unhide:no; mso-style-parent:Base_Text; margin-top:6.0pt; margin-right:0in; margin-bottom:0in; margin-left:0in; mso-pagination:widow-orphan; font-size:10.0pt; font-family:'Times New Roman','serif'; mso-fareast-font-family:'Times New Roman';");


            var autext = new List<string>();
            foreach (var p in doc.DocumentNode.Descendants("p").Where(x => x.InnerText != "&nbsp;").ToList())
            {
                cnt++;
                if (cnt == 1)
                {
                    parafirst = p;
                }
                else if (p.InnerText == "Abstract" || p.InnerText.StartsWith("keyword"))
                {
                    break;
                }
                else
                {
                    listpara.Add(p);
                }
            }
            if (listpara.Any(x => x.InnerText.Replace("&nbsp;", "").Trim().StartsWith("Address:")))
            {
                int aucnt = 0;
                var author = "";
                foreach (var x in listpara)
                {
                    aucnt++;
                    if (x.InnerText.Replace("&nbsp;", "") == "Address:")
                    {
                        break;
                    }
                    else
                    {
                        if (aucnt == 1 && x.InnerText.Contains(","))
                        {
                            author = x.InnerText.Split(',')[0];
                            var aub = doc.CreateElement("b");
                            aub.SetAttributeValue("style", "mso-bidi-font-weight:normal");
                            var span = doc.CreateElement("span");
                            span.SetAttributeValue("style", "font-size:12.0pt;mso-bidi-font-size:12.0pt;");
                            aub.AppendChild(span);
                            var sup = doc.CreateElement("sup");
                            sup.InnerHtml = "1";
                            var paratext = HtmlNode.CreateNode("#text");
                            paratext.InnerHtml = author;
                            span.AppendChild(paratext);

                            span.AppendChild(sup);
                            AUPara.AppendChild(aub);
                        }
                        x.InnerHtml = x.InnerHtml;
                        if (!x.InnerText.Replace("&nbsp;", "").Trim().StartsWith("E-mail") && !x.InnerText.Replace("&nbsp;", "").Trim().StartsWith("Phone"))
                        {
                            x.ChildNodes.ToList().ForEach(y => Affilationpara.AppendChild(y));
                        }
                    }
                }
                var super = doc.CreateElement("sup");
                super.InnerHtml = "1";
                Affilationpara.PrependChild(super);
                var Flag = false;
                foreach (var x in listpara)
                {
                    aucnt++;
                    if (x.InnerText.Replace("&nbsp;", "").StartsWith("Address:"))
                    {
                        Flag = true;
                    }
                    if (Flag == true && !x.InnerText.Replace("&nbsp;", "").Trim().StartsWith("E-mail"))
                    {
                        x.ChildNodes.ToList().ForEach(y => CORRpara.AppendChild(y));
                    }
                }
                CORRpara.InnerHtml = CORRpara.InnerHtml.Replace("Address:", "Corresponding Author:" + author + ",");

                if (CORRpara.InnerText != "" && parafirst.Name == "p")
                {
                    parafirst.ParentNode.InsertAfter(CORRpara, parafirst);
                }
                if (Affilationpara.InnerText != "" && parafirst.Name == "p")
                {
                    Affilationpara.InnerHtml = Affilationpara.InnerHtml.Replace("Address:", ",");
                    parafirst.ParentNode.InsertAfter(Affilationpara, parafirst);
                }
                if (AUPara.InnerText != "" && parafirst.Name == "p")
                {
                    parafirst.ParentNode.InsertAfter(AUPara, parafirst);
                }
                foreach (var para in listpara.ToList())
                {
                    if (!para.InnerText.Replace("&nbsp;", "").StartsWith("E-mail"))
                        para.ParentNode.RemoveChild(para);
                }
            }



            doc.Save(htmlpath, Encoding.UTF8);
        }///

        public static void CreationofAFFLCORRandAUForSageFootnote(string htmlpath)//1735 job
        {


            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.Load(htmlpath);
            int cnt = 0;
            var parafirst = doc.CreateElement("#text");
            List<HtmlNode> listpara = new List<HtmlNode>();
            List<HtmlNode> listparaaffliation = new List<HtmlNode>();
            List<HtmlNode> listparaaffliationNew = new List<HtmlNode>();

            var AUPara = doc.CreateElement("p");
            AUPara.SetAttributeValue("class", "AU");
            AUPara.SetAttributeValue("style", "mso-layout-grid-align:none;text-autospace:none;mso-style-name:AU; mso-style-unhide:no; mso-style-parent:Base_Text; margin-top:6.0pt; margin-right:0in; margin-bottom:6.0pt; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; mso-bidi-font-size:10.0pt; font-family:'Arial','sans-serif'; mso-fareast-font-family:'Times New Roman'; mso-bidi-font-family:'Times New Roman'; font-weight:bold; mso-bidi-font-weight:normal;");


            var CORRpara = doc.CreateElement("p");
            CORRpara.SetAttributeValue("class", "CORR");
            CORRpara.SetAttributeValue("style", "mso-layout-grid-align:none;text-autospace:none;mso-style-name:CORR; mso-style-unhide:no; mso-style-parent:Base_Text; margin-top:6.0pt; margin-right:0in; margin-bottom:0in; margin-left:0in; mso-pagination:widow-orphan; font-size:10.0pt; font-family:'Times New Roman','serif'; mso-fareast-font-family:'Times New Roman';");


            var autext = new List<string>();
            var auflag = false;
            var affflag = false;
            foreach (var p in doc.DocumentNode.Descendants("p").Where(x => x.InnerText != "&nbsp;").ToList())
            {
                if (!p.InnerText.EndsWith(":"))
                {
                    cnt++;
                    if (cnt == 1)
                    {
                        parafirst = p;
                        continue;
                    }
                    else if (p.InnerText.StartsWith("Guest Editors:"))
                    {
                        auflag = true;
                    }
                    else if (p.Descendants("a").Count() > 0 && p.Descendants("a").FirstOrDefault().GetAttributeValue("href", "").Contains("#_ftn"))
                    {
                        auflag = true;
                    }
                    else if (p.InnerText == "References")
                    {
                        auflag = false;
                        break;
                    }
                    else
                    {
                        auflag = false;
                    }
                    if (auflag == true)
                    {
                        listpara.Add(p);
                    }
                }
            }
            foreach (var p in doc.DocumentNode.Descendants("p").Where(x => x.InnerText != "&nbsp;").ToList())
            {
                if (p.InnerText.StartsWith("Guest Editors:"))
                {
                    auflag = true;
                }
                else if (p.InnerText == "References")
                {
                    affflag = true;

                }
                if (auflag == true && affflag && p.GetAttributeValue("class", "") == "MsoFootnoteText" && p.Descendants("a").Count() > 0 && p.Descendants("a").FirstOrDefault().GetAttributeValue("href", "").StartsWith("#_ftnref"))
                {
                    listparaaffliation.Add(p);
                }


            }
            if (listpara.Any(x => x.InnerText.Replace("&nbsp;", "").Trim().StartsWith("Guest Editors:")))
            {
                int aucnt = 0;
                var author = "";
                foreach (var x in listpara)
                {

                    aucnt++;
                    foreach (var a in x.Descendants("a").ToList())
                    {
                        a.Remove();
                    }
                    foreach (var sp in x.Descendants("span").Where(xy => xy.GetAttributeValue("style", "").Replace(" ", "") == "mso-tab-count:2").ToList())
                    {
                        sp.Remove();
                    }
                    if (x.InnerText.Contains(","))
                    {
                        author = x.InnerText.Split(',')[0].Replace("Guest Editors:", "");
                        var aub = doc.CreateElement("b");
                        aub.SetAttributeValue("style", "mso-bidi-font-weight:normal");
                        var span = doc.CreateElement("span");
                        span.SetAttributeValue("style", "font-size:12.0pt;mso-bidi-font-size:12.0pt;");
                        aub.AppendChild(span);
                        var sup = doc.CreateElement("sup");
                        sup.InnerHtml = aucnt.ToString();
                        var paratext = HtmlNode.CreateNode("#text");

                        paratext.InnerHtml = author;

                        span.AppendChild(paratext);

                        span.AppendChild(sup);
                        AUPara.AppendChild(aub);
                        if (aucnt == 1)
                        {
                            var paracomma = HtmlNode.CreateNode("#text");

                            paracomma.InnerHtml = ",";
                            AUPara.AppendChild(paracomma);
                        }
                        else if (aucnt == 2 && listpara.Count == 3)
                        {
                            var paracomma = HtmlNode.CreateNode("#text");

                            paracomma.InnerHtml = ", and ";
                            AUPara.AppendChild(paracomma);
                        }

                    }
                }
                aucnt = 0;
                foreach (var aff in listparaaffliation.ToList())
                {
                    aucnt++;
                    var Affilationpara = doc.CreateElement("p");
                    Affilationpara.SetAttributeValue("class", "AFFL");
                    Affilationpara.SetAttributeValue("style", "mso-style-name:AFFL; mso-style-unhide:no; mso-style-parent:Base_Text; mso-style-link:'AFFL Char'; margin-top:6.0pt; margin-right:0in; margin-bottom:0in; margin-left:0in; mso-pagination:widow-orphan; font-size:10.0pt; font-family:'Times New Roman','serif'; mso-fareast-font-family:'Times New Roman';");

                    foreach (var a in aff.Descendants("a").ToList())
                    {
                        a.Remove();
                    }
                    var super = doc.CreateElement("sup");
                    super.InnerHtml = aucnt.ToString();
                    Affilationpara.AppendChild(super);
                    aff.ChildNodes.ToList().ForEach(y => Affilationpara.AppendChild(y));
                    listparaaffliationNew.Add(Affilationpara);
                    if (aucnt == 1)
                    {
                        var corrspan = doc.CreateElement("span");
                        corrspan.SetAttributeValue("style", "font-size:10.0pt;mso-bidi-font-size: 12.0pt;");
                        corrspan.InnerHtml = "Corresponding Author: " + aff.InnerText;
                        CORRpara.AppendChild(corrspan);
                    }
                }
                if (CORRpara.InnerText != "" && parafirst.Name == "p")
                {
                    parafirst.ParentNode.InsertAfter(CORRpara, parafirst);
                }
                if (listparaaffliationNew.Count != 0 && parafirst.Name == "p")
                {
                    var newcnt = listparaaffliationNew.Count;
                    foreach (var affpara in listparaaffliationNew)
                    {
                        newcnt--;
                        parafirst.ParentNode.InsertAfter(listparaaffliationNew[newcnt], parafirst);
                    }
                }
                if (AUPara.InnerText != "" && parafirst.Name == "p")
                {
                    parafirst.ParentNode.InsertAfter(AUPara, parafirst);
                }
                foreach (var para in listpara.ToList())
                {
                    if (!para.InnerText.Replace("&nbsp;", "").StartsWith("E-mail"))
                        para.ParentNode.RemoveChild(para);
                }
                foreach (var para in listparaaffliation.ToList())
                {
                    if (!para.InnerText.Replace("&nbsp;", "").StartsWith("E-mail"))
                        para.ParentNode.RemoveChild(para);
                }
            }



            doc.Save(htmlpath, Encoding.UTF8);
        }

        public static void ATtoTIstyleChange(string htmlpath)//Added by vikas on  09-12-2020 for 3CM required TI style for AT
        {
            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.Load(htmlpath, Encoding.UTF8);
            doc.DocumentNode.Descendants("p").Where(x => x.GetAttributeValue("class", "") == "AT").ToList().ForEach(x => x.SetAttributeValue("class", "TI"));
            doc.Save(htmlpath, Encoding.UTF8);

        }
        public static void AddNewJournalTitle(string strWordDoc)
        {
            var JournalDB = System.Configuration.ConfigurationManager.AppSettings.Get("JournalNameDBJaypee");
            using (WordprocessingDocument WPD = WordprocessingDocument
                   .Open(strWordDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                List<string> strJournalsColl = new List<string>();
                strJournalsColl = GlobalMethods.ReadAndStoreFileValuesInArray(JournalDB);

                // Sort the Journals array on length //
                strJournalsColl = GlobalMethods.SortStringListOnLength(strJournalsColl);

                List<string> newjournaltitle = new List<string>();
                List<string> list = new List<string>();
                bool newJournalNameFound = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                       Where(e => e.ParagraphProperties != null
                           && e.ParagraphProperties.ParagraphStyleId != null
                           && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                {
                    string journalname = null;

                    if (P.HasChildren)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                if (R.RunProperties != null)
                                {
                                    if (R.RunProperties.RunStyle != null)
                                    {
                                        if (R.RunProperties.RunStyle.Val == "bibjournal")
                                        {
                                            if (R.InnerText.Trim() != "" && R.InnerText != null)
                                            {
                                                journalname = R.InnerText.Trim();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }



                    //Check if JournalList contains Journalname in text file.
                    if (!string.IsNullOrEmpty(journalname) && journalname.Trim() != "")
                    {
                        if (strJournalsColl.ToList().Contains(journalname))
                        {
                            newJournalNameFound = false;
                        }
                        else
                        {
                            newJournalNameFound = true;
                        }
                    }



                    if (newJournalNameFound)
                    {
                        if (!string.IsNullOrEmpty(journalname) && journalname.Trim() != "")
                        {
                            newjournaltitle.Add(journalname.Trim());
                        }
                    }


                }


                //Write new journal name in Journallist text file.
                if (newjournaltitle.Count > 0)
                {
                    list = newjournaltitle.Distinct().ToList();
                    StringBuilder sb = new StringBuilder();
                    int count = 1;
                    foreach (string line in list)
                    {
                        if (line.Trim() != "")
                        {
                            if (count != list.Count())
                            {
                                count++;
                                sb.AppendLine(line.Trim());
                            }
                            else
                            {
                                sb.Append(line.Trim());
                            }
                        }

                    }
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(JournalDB, true))
                    {
                        file.WriteLine("\n");
                        file.Write(sb.ToString());
                        file.Close();
                    }

                }

                D.Save();
            }
        }
        public static void CleanupExtraSpaces(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().ToList().Any(x => x.InnerText.StartsWith(" ") || x.InnerText.EndsWith(" ") || x.InnerText == " "))
                    {
                        int i = 0;
                        var Rcount = P.Descendants<Run>().ToList().Count;

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            try
                            {
                                i++;
                                //////////////If run text is equal to space
                                if (R.InnerText.Trim() == "")
                                {
                                    if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Superscript)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && nextR.RunProperties.VerticalTextAlignment == null)
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Subscript)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && nextR.RunProperties.VerticalTextAlignment == null)
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Bold != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Italic != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Underline != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    Rcount = P.Descendants<Run>().ToList().Count;

                                }



                                //////////////If run text endswith space
                                else if (R.InnerText.EndsWith(" "))
                                {
                                    if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Superscript)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling());
                                                if (nextR.RunProperties != null && nextR.RunProperties.VerticalTextAlignment == null)
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Subscript)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling());

                                                if (nextR.RunProperties != null && nextR.RunProperties.VerticalTextAlignment == null)
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Bold != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling()); if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                                {

                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Italic != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling()); if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Underline != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling());
                                                if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    Rcount = P.Descendants<Run>().ToList().Count;

                                }


                                //////////////If run text endswith space
                                else if (R.InnerText.StartsWith(" ") && i != 1)
                                {
                                    if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Superscript)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && prevR.RunProperties.VerticalTextAlignment == null)
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Subscript)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && prevR.RunProperties.VerticalTextAlignment == null)
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Bold != null)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && (prevR.RunProperties.VerticalTextAlignment == null && prevR.RunProperties.Bold == null && prevR.RunProperties.Italic == null && prevR.RunProperties.Underline == null))
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Italic != null)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && (prevR.RunProperties.VerticalTextAlignment == null && prevR.RunProperties.Bold == null && prevR.RunProperties.Italic == null && prevR.RunProperties.Underline == null))
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Underline != null)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && (prevR.RunProperties.VerticalTextAlignment == null && prevR.RunProperties.Bold == null && prevR.RunProperties.Italic == null && prevR.RunProperties.Underline == null))
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    Rcount = P.Descendants<Run>().ToList().Count;

                                }
                            }
                            catch (Exception ex)
                            {
                            }

                        }
                    }
                }
                D.Save();
                WPD.Save();
            }
        }

        public static void RemoveanchortagandunderlinefromDOI(string strDocument)
        {

            HtmlDocument newdoc = new HtmlDocument();

            newdoc.Load(strDocument, Encoding.UTF8);

            foreach (var a in newdoc.DocumentNode.Descendants("a").ToList())
            {
                var spannode = a.Descendants("span").ToList().Where(x => x.GetAttributeValue("class", "") != null && x.GetAttributeValue("class", "") == "bibdoi").ToList();
                if (spannode.Count() > 0)
                {
                    string doitext = a.InnerText;
                    HtmlNode span = newdoc.CreateElement("span");
                    span.SetAttributeValue("class", "bibdoi");
                    span.InnerHtml = doitext;
                    if (a != null && a.ParentNode != null)
                    {
                        a.ParentNode.InsertAfter(span, a);
                        a.Remove();
                    }
                }
            }
            foreach (var a in newdoc.DocumentNode.Descendants("u").ToList())
            {
                var spannode = a.Descendants("span").ToList().Where(x => x.GetAttributeValue("class", "") != null && x.GetAttributeValue("class", "") == "bibdoi").ToList();
                if (spannode.Count() > 0)
                {
                    string doitext = a.InnerText;
                    HtmlNode span = newdoc.CreateElement("span");
                    span.SetAttributeValue("class", "bibdoi");
                    span.InnerHtml = doitext;
                    if (a != null && a.ParentNode != null)
                    {
                        a.ParentNode.InsertAfter(span, a);
                        a.Remove();
                    }
                }
            }
            newdoc.Save(strDocument, Encoding.UTF8);

        }
        public static void InsertImageInWordFile(string document)
        {
            string ImagePath = GlobalMethods.strImagePath;
            if (Directory.Exists(ImagePath))
            {
                DirectoryInfo Dir = new DirectoryInfo(ImagePath);
                FileInfo[] filesForProcess = Dir.GetFiles();

                foreach (var files in filesForProcess)
                {
                    if (files.Extension == ".jpg" || files.Extension == ".png" || files.Extension == ".jpeg")
                    {
                        // string fileName = @"C:\3CMAutomation\2812022\IJDVL-961-2021-OA.01.jpg";
                        InsertAPicture(document, files.FullName);
                    }
                }
            }

        }
        public static void InsertAPicture(string document, string fileName)
        {
            try
            {
                using (WordprocessingDocument wordprocessingDocument =
                    WordprocessingDocument.Open(document, true))
                {
                    MainDocumentPart mainPart = wordprocessingDocument.MainDocumentPart;

                    ImagePart imagePart = mainPart.AddImagePart(ImagePartType.Jpeg);

                    using (FileStream stream = new FileStream(fileName, FileMode.Open))
                    {
                        imagePart.FeedData(stream);
                    }

                    AddImageToBody(wordprocessingDocument, mainPart.GetIdOfPart(imagePart), fileName);
                }

            }
            catch (Exception ex)
            {

            }
        }

        private static void AddImageToBody(WordprocessingDocument wordDoc, string relationshipId, string fileName)
        {
            string str1 = "";
            Process P = new Process();
            P.StartInfo.Arguments = fileName;
            P.StartInfo.CreateNoWindow = true;
            P.StartInfo.FileName = "ImageSize.exe";
            P.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            P.Start();
            P.WaitForExit();
            var strimgname = fileName.Replace(".jpg", ".txt").Replace(".jpeg", ".txt").Replace(".png", ".txt");
            string[] FileArr = null;
            if (File.Exists(strimgname))
            {
                StreamReader sr = new StreamReader(strimgname);
                string FileC = sr.ReadToEnd().Replace("\r", "").Replace("\n", "");
                FileArr = FileC.Split(',');
                sr.Close();
                File.Delete(strimgname);
            }
            else
            {
                return;
            }


            if (FileArr == null)
                return;
            if (FileArr.Length != 2)
                return;

            //var sizeInBytes = file.Length;
            //System.Drawing.Bitmap img = new Bitmap(fileName);
            //var imageHeight = img.Height;
            //var imageWidth = img.Width;

            str1 = fileName;
            try
            {
                Int64 lwidth = Convert.ToInt64(FileArr[1].Trim());
                Int64 lheight = Convert.ToInt64(FileArr[0].Trim());
                // Define the reference of the image.

                int multiVale = 2500;
                if (fileName.ToLower().EndsWith("png"))
                    multiVale = 4000;
                else
                    multiVale = 2500;

                var element =
                     new Drawing(
                         new DW.Inline(
                             new DW.Extent() { Cx = lwidth * multiVale, Cy = lheight * multiVale },
                             new DW.EffectExtent()
                             {
                                 LeftEdge = 0L,
                                 TopEdge = 0L,
                                 RightEdge = 0L,
                                 BottomEdge = 0L
                             },
                             new DW.DocProperties()
                             {
                                 Id = (UInt32Value)1U,
                                 Name = "Picture 1"
                             },
                             new DW.NonVisualGraphicFrameDrawingProperties(
                                 new A.GraphicFrameLocks() { NoChangeAspect = true }),
                             new A.Graphic(
                                 new A.GraphicData(
                                     new PIC.Picture(
                                         new PIC.NonVisualPictureProperties(
                                             new PIC.NonVisualDrawingProperties()
                                             {
                                                 Id = (UInt32Value)0U,
                                                 Name = "New Bitmap Image.jpg"
                                             },
                                             new PIC.NonVisualPictureDrawingProperties()),
                                         new PIC.BlipFill(
                                             new A.Blip(
                                                 new A.BlipExtensionList(
                                                     new A.BlipExtension()
                                                     {
                                                         Uri =
                                                            "{28A0092B-C50C-407E-A947-70E740481C1C}"
                                                     })
                                             )
                                             {
                                                 Embed = relationshipId,
                                                 CompressionState =
                                                 A.BlipCompressionValues.Print
                                             },
                                             new A.Stretch(
                                                 new A.FillRectangle())),
                                         new PIC.ShapeProperties(
                                             new A.Transform2D(
                                                 new A.Offset() { X = 0L, Y = 0L },
                                                 new A.Extents() { Cx = 990000L, Cy = 792000L }),
                                             new A.PresetGeometry(
                                                 new A.AdjustValueList()
                                             )
                                             { Preset = A.ShapeTypeValues.Rectangle }))
                                 )
                                 { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" })
                         )
                         {
                             DistanceFromTop = (UInt32Value)0U,
                             DistanceFromBottom = (UInt32Value)0U,
                             DistanceFromLeft = (UInt32Value)0U,
                             DistanceFromRight = (UInt32Value)0U,
                             EditId = "50D07946"
                         });

                str1 = str1 + "\nChecking";
                // Append the reference to body, the element should be in a Run.
                var figcPara = wordDoc.MainDocumentPart.Document.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC").ToList();
                if (figcPara.Count() > 0)
                {
                    foreach (var figPara in figcPara.ToList())
                    {
                        if (figPara.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "label-Strong").ToList().Count() > 0)
                        {
                            var labelStrongVal = "";
                            foreach (var labelStr in figPara.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "label-Strong").ToList())
                            {
                                labelStrongVal += labelStr.InnerText;
                            }
                            //labelStrongVal = figPara.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "label-Strong").ToList().FirstOrDefault().InnerText;
                            if (fileName.Contains("."))
                            {
                                var strimg = fileName.Split('.').ToList()[1];
                                if (strimg.StartsWith("0"))
                                {
                                    strimg = strimg.TrimStart('0');
                                }
                                if (labelStrongVal.ToLower().Replace("figure.", "").Replace("figure", "").Replace("figs.", "").Replace("fig", "").Trim().TrimEnd(':').TrimEnd('.') == strimg.ToLower())
                                {
                                    if (!string.IsNullOrEmpty(labelStrongVal))
                                    {
                                        figPara.InsertBeforeSelf(new Paragraph(new Run(element)));
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    wordDoc.MainDocumentPart.Document.Body.AppendChild(new Paragraph(new Run(element)));
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }

        }

        public static void ReplaceSpantagtoSupSubBI(string strDocument)
        {
            ReplaceSpantags(strDocument, "vertical-align:super;font-size:smaller;", "<sup>", "</sup>");
            ReplaceSpantags(strDocument, "vertical-align:sub;font-size:smaller;", "<sub>", "</sub>");
            ReplaceSpantags(strDocument, "font-weight:bold;", "<b>", "</b>");
            ReplaceSpantags(strDocument, "font-style:italic;", "<i>", "</i>");
            ReplaceSpantags(strDocument, "font-style:italic;font-weight:bold;", "<b><i>","</i></b>");
            ReplaceSpantags(strDocument, "font-style:bold;font-weight:italic;", "<b><i>", "</i></b>");

        }
        public static void ReplaceSpantags(string strDocument, string stag, string rstag, string retag)
        {

            HtmlDocument newdoc = new HtmlDocument();
            newdoc.Load(strDocument, Encoding.UTF8);
            string[,] StrTag = null;           
            try
            {

                var spanNodes = newdoc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "formatchange").Where(y => y.GetAttributeValue("style", "") == stag).ToList();
                int CntNode = spanNodes.Count;
                StrTag = new string[CntNode, 2];
                if (spanNodes != null)
                {
                    for (int x = 0; x < spanNodes.Count; x++)
                    {
                        StrTag[x, 0] = spanNodes[x].OuterHtml.ToString();
                        StrTag[x, 1] = rstag + spanNodes[x].InnerHtml + retag;                     
                    }

                }

                
                StreamReader sr = new StreamReader(strDocument,Encoding.UTF8);
                string FileC = sr.ReadToEnd();
                
                sr.Close();
                for (int x = 0; x < StrTag.GetLength(0); x++)
                {
                    FileC = FileC.Replace(StrTag[x, 0], StrTag[x, 1]);
                }

                File.Delete(strDocument);
                StreamWriter sw = new StreamWriter(strDocument,false,Encoding.UTF8);               

                sw.Write(FileC);
                sw.Close(); 
            }
            catch (Exception Ex)
            { }
        }


        public static void ReplaceSpantagtoSupSub(string strDocument)
        {

            HtmlDocument newdoc = new HtmlDocument();

            newdoc.Load(strDocument, Encoding.UTF8);
            string [,] StrSup = null;
            string[,] StrSub = null;
            string[,] StrBold = null;
            string[,] StrItalic = null;
            string[,] StrBI = null;
            string[,] StrIB = null;
            try
            {

                var spanNodes = newdoc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "formatchange").Where(y => y.GetAttributeValue("style", "") == "vertical-align:super;font-size:smaller;").ToList();
                int CntNode = spanNodes.Count;
                StrSup = new string[CntNode, 2];
                if (spanNodes != null)
                {
                    for (int x = 0; x < spanNodes.Count; x++)
                    {
                        HtmlNode sup = spanNodes[x];
                        HtmlNode x1 = newdoc.CreateElement("sup");
                        // x1.NodeType = HtmlNodeType.Element;
                        x1.InnerHtml = sup.InnerHtml;
                        //spanNodes[x] = x1;
                        StrSup[x, 0] = spanNodes[x].OuterHtml.ToString();
                        StrSup[x, 1] = x1.OuterHtml.ToString();

                        //sup = x1;
                    }
                    /*foreach (HtmlNode sup in spanNodes)
                        {
                            var S = sup.InnerHtml;
                            var text = "<sup>" + S + "</sup>";
                        //sup.ParentNode.InnerHtml = "<sup>" + sup.InnerHtml + "</sup>";
                        //sup.InnerHtml = "<sup>" + sup.InnerHtml + "</sup>";                      
                        HtmlNode x = sup;
                        x.InnerHtml = sup.InnerHtml;
                        sup = x;                      


                    }*/
                }

                StreamReader sr = new StreamReader(strDocument);
                string FileC = sr.ReadToEnd();
                sr.Close();
                for (int x = 0; x < StrSup.GetLength(0); x++)
                {
                    FileC = FileC.Replace(StrSup[x, 0], StrSup[x, 1]);
                }

                File.Delete(strDocument);
                StreamWriter sw = new StreamWriter(strDocument);
                sw.Write(FileC);
                sw.Close();


                var spanNodes1 = newdoc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "formatchange").Where(y => y.GetAttributeValue("style", "") == "vertical-align:sub;font-size:smaller;").ToList();

                if (spanNodes1 != null)
                {
                    int CntNode1 = spanNodes1.Count;
                    StrSub = new string[CntNode1, 2];
                    foreach (var sub in spanNodes1)
                    {
                        var S1 = sub.InnerHtml;
                        var text = "<sub>" + S1 + "</sub>";
                        sub.InnerHtml = "<sub>" + sub.InnerHtml + "</sub>";
                      //  StrSub[x, 0] = spanNodes[x].OuterHtml.ToString();
                      //  StrSub[x, 1] = x1.OuterHtml.ToString();


                    }
                }

                var spanNodes2 = newdoc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "formatchange").Where(y => y.GetAttributeValue("style", "") == "font-weight:bold;").ToList();
                if (spanNodes2 != null)
                {
                    int CntNode2 = spanNodes2.Count;
                    StrBold = new string[CntNode2, 2];
                    foreach (var Bold in spanNodes2)
                    {
                        var B = Bold.InnerHtml;
                        var text = "<b>" + B + "</b>";
                        Bold.InnerHtml = "<b>" + Bold.InnerHtml + "</b>";
                    }
                }

                var spanNodes3 = newdoc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "formatchange").Where(y => y.GetAttributeValue("style", "") == "font-style:italic;").ToList();
                if (spanNodes3 != null)
                {
                    int CntNode3 = spanNodes3.Count;
                    StrItalic = new string[CntNode3, 2];
                    foreach (var Italic in spanNodes3)
                    {
                        var I = Italic.InnerHtml;
                        var text = "<i>" + I + "</i>";
                        Italic.InnerHtml = "<i>" + Italic.InnerHtml + "</i>";
                    }
                }

                var spanNodes4 = newdoc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "formatchange").Where(y => y.GetAttributeValue("style", "") == "font-style:italic;font-weight:bold;").ToList();
                if (spanNodes4 != null)
                {
                    int CntNode4 = spanNodes4.Count;
                    StrIB = new string[CntNode4, 2];
                    foreach (var IB in spanNodes4)
                    {
                        var iB = IB.InnerHtml;
                        var text = "<i><b>" + iB+ "</i></b>";
                        IB.InnerHtml = "<i><b>" + IB.InnerHtml + "</i></b>";
                    }
                }


                var spanNodes5 = newdoc.DocumentNode.SelectNodes("//span").ToList().Where(x => x.GetAttributeValue("class", "") == "formatchange").Where(y => y.GetAttributeValue("style", "") == "font-style:bold;font-weight:italic;").ToList();
                if (spanNodes5 != null)
                {
                    int CntNode5 = spanNodes5.Count;
                    StrBI = new string[CntNode5, 2];
                    foreach (var BI in spanNodes4)
                    {
                        var bI = BI.InnerHtml;
                        var text = "<b><i>" + bI + "</b></i>";
                        BI.InnerHtml = "<b><i>" + BI.InnerHtml + "</b></i>";
                    }
                }
            
                newdoc.Save(strDocument, Encoding.UTF8);

            }
            catch (Exception ex)
            {

            }

        }

    }
}
